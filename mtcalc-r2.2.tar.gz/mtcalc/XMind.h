/* TYPEDEFS */

#ifndef _XMIND_INCLUDED
#define _XMIND_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif


typedef struct {                        /* Animation pixmap data        */
        Widget   w;
        Cardinal actualFrame;           /* Current frame to display     */
        Cardinal maxFrame;              /* Number of frames             */
        Cardinal counter;               /* How many times to play       */
        unsigned long time;             /* Intervall time in msec       */
        Pixmap  *pixmap;
	XtIntervalId id;		/* Intervall Id			*/
}AnimData;

typedef struct {
	char *	Qhelp_name;
	Widget	Qhelp_widget;
	char *	Hyper_object;
	char *	Hyper_file;
}USER_DATA;

#define XPM	1
#define XWD	2
#define XBM	3

#ifdef ANSI
#define P(x) x
#else
#define P(x) ()
#endif

/* Create Widgets Prototypes */

Widget MCreateAnimButton P((Widget parent, String name,String pixmapName, Cardinal pixmapNum, Cardinal loop, unsigned long thistime, Arg *args, Cardinal argcount));
Widget MCreateDrawnButton P((Widget parent, String name,String pixmapName, Arg *args, Cardinal argcount));
Widget MCreatePixmapButton P((Widget parent, String name,String pixmapName, Arg *args, Cardinal argcount));

/* Non static callback functions */

void PixmapExposeCb(Widget parent, char *name, XmDrawnButtonCallbackStruct *cbs);
/* Access Widgets Prototypes */

int 	MTextGetInt P((Widget parent));
void 	MTextGetFloat P((Widget parent, double *value));
Bool 	MTextSetInt P((Widget parent, int value));
Bool 	MTextSetFloat P((Widget parent, double value));
Bool 	MTextSetString P((Widget parent, char *value));
char *  MTextGetString P((Widget parent));
unsigned int MTextGetHex(Widget parent);
Bool    MTextSetHex(Widget parent, int value);
Bool 	MScaleSetFloat P((Widget parent, double value));
void 	MScaleGetFloat P((Widget parent, double *value));
char   *MListGetString P((Widget parent));
Bool 	MListSetString P((Widget parent, char *item));
int 	MListGetPosition P((Widget parent));
void 	MListDeleteAllItems P((Widget parent));
Bool    MListReplaceItem(Widget parent, XmString item, XmString newItem);
void 	MListSelectAllItems P((Widget parent));
Pixel   MGetPixelByName(char *str);
Pixel   MGetPixel(char *str, Widget w);
char   *MGetString P((XmString xstr));
char   *MRadioGetSelectedItem P((Widget parent));
int     MRadioGetSelectedPos P((Widget parent));
Bool    MRadioSetPosition(Widget parent, int pos);
Widget  MRadioGetWidget(Widget parent, int pos);
void 	MCloseDialog P((Widget wid));
char   *MGetString P((XmString xstr));
Bool    MGrabDelete P((Widget wid, XtCallbackProc call, XtPointer closure));
char  **MListGetStrings P((Widget parent));
Bool    MListAddStrings P((Widget parent, char **items, int number));
int    *MListGetPositions P((Widget parent));
int     MListGetSelectedCount P((Widget parent));
XmString MStringCreate P((char *str));
void    MListPositionVisible P((Widget parent, int ThePosition));
char   *TstStr P((char *s));
char   *MOptionGetItem P((Widget parent));
int     MOptionGetPosition P((Widget parent));
Widget  MOptionGetWidget(Widget parent, int pos);
Boolean MOptionSetPosition(Widget parent, int pos);
Widget  MOptionAddItem(Widget OptionMenu, char *item);
char   *MMakeFilename P((char *Fn, char *Path));
char   *MMakePixmapName P((char *Fn));
Bool    MMessageBoxSetText(Widget parent, char *text);
Bool    MListSort P((Widget parent));
void 	MSetFocus(Widget destination);
Bool    MTextWrite P((Widget parent, char *filename));
Bool    MTextInsert P((Widget parent, char *filename));
Bool    MTextRead P((Widget parent, char *filename));
Pixmap  MLoadPixmap P((Widget parent, char *filename));
Pixmap  MLoadXBM P((Widget parent, char *filename));
Pixmap  MLoadXPM P((Widget parent, char *filename));
Pixmap  MLoadGraphic P((Widget parent, char *filename, int *format));
Pixmap  MLoadGraphics P((Widget parent, char *filename, int format));
Bool    MListAddString P((Widget parent, char *item));
Bool    MWritePixmap P((Widget parent, char *filename, Pixmap pix));
char   *MGetQuickHelp(Widget w);
void Qtip(Widget widget,char *text);


/* CALLBACKS */

void AnimButtonExposeCb P((Widget parent, AnimData *data, XmAnyCallbackStruct *cbs));
void MPostPopupMenu P((Widget w, Widget popup, XButtonEvent *event));
void MNextCb P((Widget wid, Widget data, XmAnyCallbackStruct *cbs));
void MSetQuickhelp P((Widget parent, USER_DATA *data, XEvent *event));
void MDestroyQuickhelp P((Widget parent, USER_DATA *data, XmAnyCallbackStruct *cbs));


/* READ AND WRITE XWD-FILES */

XImage *ReadXWD(char *file_name, Widget parent);

/* READ AND WRITE XPM-FILES */

Bool 	MWriteXPM(Widget parent, char *filename, Pixmap pix);
Pixmap 	MReadXPM(Widget parent, char *filename);
Pixmap 	MLoadXPM(Widget parent, char *filename);
Bool 	MCheckXpmStatus(int stat);

/* FUNCTIONS IN text_funcs.c */

int ModifyVerifyCheckOnFloat(Widget w, XmTextVerifyCallbackStruct *cbs);
void ModifyVerifyCheckOnFloatCb(Widget w, XtPointer cbs, XtPointer Data);

int ModifyVerifyCheckOnInt(Widget w, XmTextVerifyCallbackStruct *cbs);
void ModifyVerifyCheckOnIntCb(Widget w, XtPointer cbs, XtPointer Data);

int ModifyVerifyCheckOnHex(Widget w, XmTextVerifyCallbackStruct *cbs);
void ModifyVerifyCheckOnHexCb(Widget w, XtPointer data, XtPointer cbs);

int ModifyVerifyCheckOnOct(Widget w, XmTextVerifyCallbackStruct *cbs);
void ModifyVerifyCheckOnOctCb(Widget w, XtPointer data, XtPointer cbs);

int ModifyVerifyCheckOnBin(Widget w, XmTextVerifyCallbackStruct *cbs);
void ModifyVerifyCheckOnBinCb(Widget w, XtPointer data, XtPointer cbs);

int ModifyVerifyCheckOnLetter(Widget w, XmTextVerifyCallbackStruct *cbs);
void ModifyVerifyCheckOnLetterCb(Widget w, XtPointer data, XtPointer cbs);

int ModifyVerifyCheckOnCName(Widget w, XmTextVerifyCallbackStruct *cbs);
void ModifyVerifyCheckOnCNameCb(Widget w, XtPointer data, XtPointer cbs);

int ModifyVerifyCheckOnLen(Widget w, XmTextVerifyCallbackStruct *cbs, int MaxLen);

int ModifyVerifyCheck(Widget w, XmTextVerifyCallbackStruct *cbs, char *Chars);
void ActivationHex2IntCb(Widget w, XtPointer unused1, XtPointer unused2);
char *ModifyVerifyResult(Widget w, XmTextVerifyCallbackStruct *cbs);

char * MTextGetPassword(void);
void MotionVerifyPasswordCb(Widget w, XtPointer data, XmTextVerifyCallbackStruct *cbs);
void ModifyVerifyPasswordCb(Widget w, XtPointer data, XmTextVerifyCallbackStruct *cbs);

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration which encloses file. */
#endif

#endif
