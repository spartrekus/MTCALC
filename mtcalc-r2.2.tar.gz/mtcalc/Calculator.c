/* Created by EasyMotif $Revision: 2.3 $  */

/*
 *	Project:	Calculator		Path:	/home/keidel/Brainstorm/Mind/test/Rechner/
 *	Program-name:	Calculator
 *	Designer:	J.Keidel		Version:	Unknown
 *	Description:	Programmable Hex-Calculator
*/
/* 	Includes */

#include <Xm/XmAll.h>
#include <XMind.h>
#include <X11/xpm.h>
#include <math.h>

/*** PRIVATE HEADER ***/ 


/*   PRIVATE INCLUDE   */
#include <X11/cursorfont.h>
#include <stdlib.h>
#include  <limits.h>
#include <values.h>
#include   "Motifdialog.h"
/*   PRIVATE DEFINES   */

typedef unsigned long int u_long_int;

#define  MAXownFunct	50

#define OWNcodefile	".calcfunc"
/*  we need prototypes of Functions used in function array at this point, prior to array setting */

static double mysin(double val);
static double mycos(double val);
static double mytan(double val);
static double myacos(double val);
static double myasin(double val);
static double myatan(double val);
static long myrand(long int val);
static double mylog(double val);
static double myln(double val);
static long lsbfirst (long  int hexin) ;


typedef struct {
	char *code;		/* string of code allocated when needed */
	int	type;		/*    1== double, 0,2,3 = long int  */
	char functionname[5];	/* name   % + 3 chars */
  }OWNCODE;


typedef struct  rev {
	struct rev		*next;	/* zero if no next   => end */
	struct rev		*back;	/* zero if  first  */
	double	      	 value;	/* value and its pendant ivalue should contain the same values */
	long int		ivalue ;	/* same as value, but integer */
	short int	     	 datatype;  /* actual type to be used  */
	short int	       	 priority;
	short int	     	itemtype;  /* 0 == value  1== pointer variable  2 == execution code
				   3 == double function 4 == long int function 
				   5 == double owncode  6 == lon int owncode */
        short int		code;	/* execution code */
        union   {
            double   (*dfunction)(double );
            long  (*ifunction)(long int);
	    OWNCODE   *ownfunc;
            }func;
        char		paraname[17];	/* for inputnames stored paramname	max length 16 chars*/
       }REVP;

typedef struct functcall{	/* structure to save all relevant values for owncode call */
	struct functcall  *next;
	struct functcall  *back;
	double	      	 value;	/* value and its pendant ivalue should contain the same values */
	long int	ivalue ;	/* same as value, but integer transfer value to function*/
        REVP	*STACKtop ;  		/* stack saved*/
	REVP	*calcbottom ;		/* calculation queue bottom saved */
	REVP	*calctop ;		/* calculation queue top saved */
	int      datatype;		/* save datatype (will switch now to function type) */
	char    *string;
	char   *functionname;
     }OWNCODECALL;	

typedef struct {
                   double        (*dfunction)(double );
                   long    	 (*ifunction)(long int);
	  short int	 functype;  /* 1== double, 0,2,3 = long int  */
	  char		 funcname[5];
      }Funct;	  

 /*************     add FUNCTION as %XXX     (three chars + %)         */ 	
/*  function always followed by PAROPEN!!!!!!   enforce it , handle it as value lateron */

#define nfunctions	12

Funct   funcs[nfunctions]={{NULL,lsbfirst,2,"%LSB"},
			   {mysin,NULL,1,"%SIN"},
			   {mycos,NULL,1,"%COS"},
			   {mytan,NULL,1,"%TAN"},
			   {myasin,NULL,1,"%ASI"},
			   {myacos,NULL,1,"%ACO"},
			   {myatan,NULL,1,"%ATA"},
			   {exp,NULL,1,"%EXP"},
			   {fabs,NULL,1,"%ABS"},
			   {myln,NULL,1,"%LNA"},
			   {mylog,NULL,1,"%LOG"},
			   {NULL,myrand,0,"%RAN"}
			  };


#define ncommands    4  
#define nhexcommands  6
 

static int insertmode = 0;		/* 0 == add, 1 == insert current  */

enum types{HEX = 0,DECIMAL,OCTAL,BINARY};
static int datatype = DECIMAL;
/* colors for modes:   decimal  green , hex  cyan , octal  gold , binary = orangered */
static int calcmode =0;		/* 0 = immediate,(green) 1 = formula (gold)
				   2 = Programming (red) */
static char commands [ncommands+1] = "+-*/";
static char hexcommands[nhexcommands+1] = "&|^><~";

/* SIGN as command now, function only one input vale */
enum comms{PLUS=1,MINUS,MAL,DIV,POTENZ,SIGN=70,FUNC,EQUAL=200,PAROPEN=100,PARCLOSE};
/*                                                               ***********************                                                     */
enum hexcomms{AND=50,OR,XOR,LSHIFT,RSHIFT,NOT=80};
enum prios{PAND=10,POR,PSHIFT,PPLUS,PMINUS,PMAL,PDIV,PPOTENZ,PSIGN,PNOT,PFUNCTION,PPAROPEN,PPARCLOSE,PEQUAL};
/*                                                                       *********************************               */
#define POTENZ  10

static char posscommands[40];	/* conversion will copy all possible commands together */
static  short int execs[ncommands] = {PLUS,MINUS,MAL,DIV};
static  short int prio[ncommands]={PPLUS,PMINUS,PMAL,PDIV};

static short int hexexecs[nhexcommands] = {AND,OR,XOR,RSHIFT,LSHIFT,NOT};
static short int hexprio[nhexcommands] = {PAND,POR,POR,PSHIFT,PSHIFT,PNOT};
static short int possexecs[40];
static short int possprios[40];
static int npossexecs;
static int nactcomm = 0;	/* actual number of active commands (in Immediate is limit 1*/
static int signmode = 1 ;	/* mode of integer operation 0 = unsigned */

static int Error = 0;		/* global error flag */
static Widget Error_E = 0;  

static int trigmode = 0;	/*  0 == degree mode */
          	
static REVP	*STACKtop = NULL;  		/* stack base */
static REVP	*calcbottom = NULL;
static REVP	*calctop = NULL;

static OWNCODECALL *OWNcode = NULL;		/* stack base for owncodes */

static OWNCODE  OWNfuncts[MAXownFunct];
static long int NownFunct =0 ;

static int programmode = 0;		/* programming sub mode 0 = program, 1 = edit  2= delete */
					/* valid only for klick to owncode functions */

static int logging = 0;
static Widget logger = 0;

static Cursor  editcursor , delcursor;
static Widget ownfunction = 0;
/***  END   HEADER   ***/


/*	STATIC GLOBAL WIDGETS */

static Widget Calc;
static Widget Calc_num;
static Widget Calc_num_hex;
static Widget Calc_num_7;
static Widget Calc_num_8;
static Widget Calc_num_9;
static Widget Calc_num_4;
static Widget Calc_num_5;
static Widget Calc_num_6;
static Widget Calc_num_1;
static Widget Calc_num_2;
static Widget Calc_num_3;
static Widget Calc_num_point;
static Widget Calc_display;
static Widget Calc_hexop;
static Widget Calc_form111_pushButton1;
static Widget Calc_Xinput;
static Widget Calc_paropen;
static Widget Calc_parclose;
static Widget Calc_result;
static Widget Calc_functions;
static Widget Calc_ownfunctions;
static Widget Calc_nummode;
static Widget Calc_numdez;
static Widget Calc_mode;
static Widget Calc_form_mode;
static Widget Calc_logger;
static Widget Error_E;
static Widget Error_error;
static Widget own_input;
static Widget own_result;
static Widget own_mode;
static Widget own_name;
static Widget Logprint_printer;
static Widget Logprint_log;

/*	Prototypes */

Widget Calc_Create (Widget parent );
Widget Error_E_Create (Widget parent , char *message );
static Widget own_Create (Widget parent );
static Widget Logprint_Create (Widget parent );

/*	CALLBACKS */
static void bd_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void ba_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void be_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bc_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bf_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bb_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b7_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b8_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b9_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b4_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b5_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b6_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b1_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b2_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b3_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void b0_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bdot_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void signchange_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void verifyinput_cb (Widget parent , XtPointer data , XmTextVerifyCallbackStruct *  cbs);
static void inputvalchange_cb (Widget parent , XtPointer data , XmTextVerifyCallbackStruct *  cbs);
static void inputactivate_cb (Widget parent , XtPointer data , XmTextVerifyCallbackStruct *  cbs);
static void band_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bor_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bxor_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void blshift_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void brshift_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bnot_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bplus_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bmin_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bmal_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bdiv_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bpotenz_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bX_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bopenpar_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bclospar_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void bequal_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void quit_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void result_cb (Widget parent , XtPointer data , XmTextVerifyCallbackStruct *  cbs);
static void setdegmode_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void setradmode_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void setsigned_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void setunsigned_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void setaddmode_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void setinsertmode_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void clearall_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void intfuncs_cb (Widget parent , XtPointer data , XmListCallbackStruct *  cbs);
static void ownselect_cb (Widget parent , XtPointer data , XmListCallbackStruct *  cbs);
static void setconstant_cb (Widget parent , XtPointer data , XmListCallbackStruct *  cbs);
static void setdecimal_cb (Widget parent , XtPointer data , XmToggleButtonCallbackStruct *  cbs);
static void sethex_cb (Widget parent , XtPointer data , XmToggleButtonCallbackStruct *  cbs);
static void setoctal_cb (Widget parent , XtPointer data , XmToggleButtonCallbackStruct *  cbs);
static void setbinary_cb (Widget parent , XtPointer data , XmToggleButtonCallbackStruct *  cbs);
static void setimmediate_cb (Widget parent , XtPointer data , XmToggleButtonCallbackStruct *  cbs);
static void setformula_cb (Widget parent , XtPointer data , XmToggleButtonCallbackStruct *  cbs);
static void setprogram_cb (Widget parent , XtPointer data , XmToggleButtonCallbackStruct *  cbs);
static void logpr_cb (Widget parent , XtPointer data , XmToggleButtonCallbackStruct *  cbs);
static void errorbell_xb (Widget parent , XtPointer data , XmTextVerifyCallbackStruct *  cbs);
static void Errorquit_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void test_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void saveowncode_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void pgmquit_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void pgmsubpgm_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void pgmsubedit_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void pgmsubdel_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void logquit_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void log_print_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);
static void log_clear_cb (Widget parent , XtPointer data , XmPushButtonCallbackStruct *  cbs);

/*	FUNCTIONS */

static int allocateownfunc (int index,char *function , char *funcname,int type) ;
static void calcerror (char *message) ;
static void calcformula (char **input , Widget result) ;
static u_long_int calcint(unsigned long int val1 , unsigned long int val2 , int code) ;
static void calcowncode (char **input ,REVP *result) ;
static REVP *calcrevp (REVP *bottom) ;
static double calculfloat (double val1,double val2,int code) ;
static void closeownfunction (void) ;
static void  convertall (int mode , Widget target) ;
static int countparenth (char *string) ;
double decodefloat (char *string) ;
static u_long_int decodeint (char *string) ;
static REVP *decodeitem (char **string) ;
static void display_allowncode (void) ;
static void dobutton (char *insert);
static void dofunc (REVP *item ,REVP *operand) ;
static void doowncode (REVP *item ,REVP *operand) ;
static int dorevp (REVP *item) ;
static char *execute_immediate (char *string) ;
REVP *getcalc (void) ;
static int getownfunction (char *name) ;
static void logit (char *res) ;
static long lsbfirst (long  int hexin) ;
static void makeposscomm (void) ;
int maycommand (char *input, int nchars) ;
static double myacos (double val) ;
static double myasin (double val) ;
static double myatan (double val) ;
static double mycos (double val) ;
static double myln (double val) ;
static double mylog (double val) ;
static long myrand (long int val) ;
static double mysin (double val) ;
static double mytan (double val) ;
static REVP *poprevp (void) ;
static void printdec (char *item,double val) ;
static int pushrevp (REVP *item) ;
static void setbintype (void) ;
static void setdeztype (void) ;
static void sethextype (void) ;
static void setocttype (void) ;
static int tocalc (REVP *item) ;


/*  FALLBACK RESOURCES */
 static String fallback_resources[] = { 
/***********************************************************
 *
 * Insert additional fallbacks
 *
 * Syntax:
 * "ResourceName*WidgetName.Resource:   Value",<NEWLINE>
 *
 * Example:
 * "MyProg*myButton.fontList:   6x10",
 *
 ***********************************************************/
"Calc*fontList:    -*-helvetica-bold-r-normal-*-12-*-*-*-*-*-*-*",
"Calc*numbutton.fontList:  -*-courier-bold-r-normal-*-14-*-*-*-*-*-*-*",
"Calc*commbutton.fontList:         -*-courier-bold-r-normal-*-18-*-*-*-*-*-*-*",
"Calc*form2.x:     +500",
"Calc*title.fontList:     -adobe-helvetica-bold-r-normal-*-17-*-*-*-*-*-*-*",
"Calc*help.background:     LightGreen",
"Calc*quit.background:       red",


"Calc*Form6*textField.background: WHITE",
"Calc*Form6*help.background: lightgreen",
"Calc*Form6*rowColumn2.fractionBase: 6",
"Calc*Form6*quit.background: red",
"Calc*Form6*quit.foreground: black",
"Calc*Form6*quit.fontList: -adobe-*-bold-r-*-*-12-*-*-*-*-*-*-*",
"Calc*Form6*rowColumn.rowColumn.toggleButton.foreground: black",
"Calc*Form6*rowColumn1.rowColumn1.program.foreground: black",
"Calc*form1*error.background: red",
  NULL 
};
/*************************************************************************** 
 ***************************************************************************
 *
 *  Functionname:	main
 *
 *  Input:			int argc; char *argv[]
 *
 *  Return:			int		
 *
 *
 ***************************************************************************
 ***************************************************************************/
int main(int argc,char **argv){
  XtAppContext app_context;
  Widget Toplevel, MainDialog;
  /* INITIALIZE THE TOPLEVEL */

	Toplevel = XtAppInitialize(&app_context, "Calc", NULL, 0, &argc, argv, fallback_resources, NULL, 0);

	  /* CREATE THE MAINDIALOG */

	MainDialog = Calc_Create(Toplevel);
  /* MANAGE AND REALIZE THE SHELL WIDGETS */

	XtManageChild(MainDialog);
	XtRealizeWidget(Toplevel);

  /* START THE MESSAGE-QUEUE */
	XtAppMainLoop(app_context);
	return 0;
}

/*************************************************************************** 
 * 
 * Funktionsname:	Calc_Create
 * 
 * 
 * Input:		Widget parent
 * 
 * Return:		Widget 
 * 
 * Dokumentation:		
 * 
 * 
 ***************************************************************************/

Widget Calc_Create (Widget parent ){
  Arg args[40]; 
  Cardinal n;
  XmString tmpLabelString = NULL;
Widget F_Calc_num;
Widget F_Calc_num_hex;
Widget Calc_num_hex_D;
Widget Calc_num_hex_A;
Widget Calc_num_E;
Widget Calc_num_C;
Widget Calc_num_F;
Widget Calc_num_hex_B;
Widget Calc_Fo7_Fo11;
Widget F_Calc_Fo7_Fo11;
Widget Calc_num_0;
Widget Calc_num_sign;
Widget Calc_help;
Widget F_Calc_hexop;
Widget Calc_hexop_pushButton2;
Widget Calc_hexop_pushButton4;
Widget Calc_hexop_pushButton12;
Widget Calc_hexop_pushButton8;
Widget Calc_hexop_pushButton6;
Widget Calc_hexop_pushButton10;
Widget Calc_form111;
Widget F_Calc_form111;
Widget Calc_form111_pushButton2;
Widget Calc_form111_pushButton3;
Widget Calc_form111_pushButton4;
Widget Calc_form111_pushButton8;
Widget Calc_form111_pushButton17;
Widget Calc_pushButton19;
Widget Calculator_tri;
Widget Calculator_Error_E_cB131;
Widget Calculator_Error_E_cB141;
Widget Calc_rowColumn318;
Widget Calc_cascadeButton119;
Widget Calc_cascadeButton120;
Widget Calc_edit;
Widget Calc_cascadeButton234;
Widget Calc_cascadeButton235;
Widget Calc_clearall;
Widget Calc_const;
Widget Calc_rowColumn5_toggleButton1;
Widget Calc_rowColumn5_toggleButton2;
Widget Calc_rowColumn5_toggleButton3;
Widget Calc_rowColumn110_TB11;
Widget Calc_rowColumn110_TB33;
Widget Calc_label124;
Widget Calc_label229;
Widget Calc_wizant;

  /* Init-functions */

	memset (OWNfuncts,0,MAXownFunct * sizeof(OWNCODE));

   /* Main Dialog */

	n = 0;
	 XtSetArg(args[n], XmNwidth, 475); n++;
	XtSetArg(args[n], XmNheight, 331); n++;
	XtSetArg(args[n], XmNautoUnmanage, FALSE); n++;
	XtSetArg(args[n], XmNnoResize, FALSE); n++;
	XtSetArg(args[n], XmNdefaultPosition, TRUE); n++;
	Calc = XmCreateForm(parent, "Form6", args, n);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 53); n++;
	XtSetArg(args[n], XmNy, 66); n++;
	XtSetArg(args[n], XmNwidth, 118); n++;
	XtSetArg(args[n], XmNheight, 232); n++;
	XtSetArg(args[n], XmNshadowType,XmSHADOW_ETCHED_IN); n++;
	F_Calc_num= XmCreateFrame(Calc, "frame", args, n);
	XtManageChild(F_Calc_num);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 53); n++;
	XtSetArg(args[n], XmNy, 66); n++;
	XtSetArg(args[n], XmNwidth, 118); n++;
	XtSetArg(args[n], XmNheight, 232); n++;
	Calc_num = XmCreateForm(F_Calc_num, "form", args, n);
	XtManageChild(Calc_num);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 15); n++;
	XtSetArg(args[n], XmNwidth, 118); n++;
	XtSetArg(args[n], XmNheight, 66); n++;
	XtSetArg(args[n], XmNshadowType,XmSHADOW_ETCHED_IN); n++;
	F_Calc_num_hex= XmCreateFrame(Calc_num, "frame", args, n);
	XtManageChild(F_Calc_num_hex);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 15); n++;
	XtSetArg(args[n], XmNwidth, 118); n++;
	XtSetArg(args[n], XmNheight, 66); n++;
	XtSetArg(args[n],XmNfractionBase ,6);n++;
	Calc_num_hex = XmCreateForm(F_Calc_num_hex, "form", args, n);
	XtManageChild(Calc_num_hex);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,3);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,2);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 2); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("D", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_hex_D = XmCreatePushButton(Calc_num_hex, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_hex_D);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,3);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,2);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNwidth, 2); n++;
	XtSetArg(args[n], XmNheight, 63); n++;
	tmpLabelString = XmStringCreateLtoR("A", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_hex_A = XmCreatePushButton(Calc_num_hex, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_hex_A);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,3);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,2);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNrightPosition,4);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 2); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 2); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("E", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_E = XmCreatePushButton(Calc_num_hex, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_E);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,3);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNleftPosition,4);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 4); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNwidth, 114); n++;
	XtSetArg(args[n], XmNheight, 63); n++;
	tmpLabelString = XmStringCreateLtoR("C", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_C = XmCreatePushButton(Calc_num_hex, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_C);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,3);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,4);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 4); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 114); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("F", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_F = XmCreatePushButton(Calc_num_hex, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_F);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,3);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNleftPosition,2);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNrightPosition,4);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 2); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNwidth, 2); n++;
	XtSetArg(args[n], XmNheight, 63); n++;
	tmpLabelString = XmStringCreateLtoR("B", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_hex_B = XmCreatePushButton(Calc_num_hex, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_hex_B);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 91); n++;
	XtSetArg(args[n], XmNwidth, 118); n++;
	XtSetArg(args[n], XmNheight, 140); n++;
	XtSetArg(args[n], XmNshadowType,XmSHADOW_ETCHED_IN); n++;
	F_Calc_Fo7_Fo11= XmCreateFrame(Calc_num, "frame", args, n);
	XtManageChild(F_Calc_Fo7_Fo11);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 91); n++;
	XtSetArg(args[n], XmNwidth, 118); n++;
	XtSetArg(args[n], XmNheight, 140); n++;
	XtSetArg(args[n],XmNfractionBase ,12);n++;
	Calc_Fo7_Fo11 = XmCreateForm(F_Calc_Fo7_Fo11, "Form_11", args, n);
	XtManageChild(Calc_Fo7_Fo11);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,3);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,4);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 4); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("7", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_7 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_7);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,3);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,4);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNrightPosition,8);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 4); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 4); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("8", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_8 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_8);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,3);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,8);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 8); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 110); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("9", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_9 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_9);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,3);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,6);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,4);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNwidth, 4); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("4", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_4 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_4);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,3);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,6);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,4);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNrightPosition,8);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 4); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNwidth, 4); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("5", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_5 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_5);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,3);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,6);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,8);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 8); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNwidth, 110); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("6", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_6 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_6);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,6);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,9);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,4);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 6); n++;
	XtSetArg(args[n], XmNwidth, 4); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("1", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_1 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_1);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,6);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,9);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,4);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNrightPosition,8);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 4); n++;
	XtSetArg(args[n], XmNy, 6); n++;
	XtSetArg(args[n], XmNwidth, 4); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("2", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_2 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_2);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,6);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,9);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,8);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 8); n++;
	XtSetArg(args[n], XmNy, 6); n++;
	XtSetArg(args[n], XmNwidth, 110); n++;
	XtSetArg(args[n], XmNheight, 3); n++;
	tmpLabelString = XmStringCreateLtoR("3", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_3 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_3);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,9);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,4);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 9); n++;
	XtSetArg(args[n], XmNwidth, 4); n++;
	XtSetArg(args[n], XmNheight, 131); n++;
	tmpLabelString = XmStringCreateLtoR("0", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_0 = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_0);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,9);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNleftPosition,4);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNrightPosition,8);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 4); n++;
	XtSetArg(args[n], XmNy, 9); n++;
	XtSetArg(args[n], XmNwidth, 4); n++;
	XtSetArg(args[n], XmNheight, 131); n++;
	tmpLabelString = XmStringCreateLtoR(".", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_point = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_point);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,9);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNleftPosition,8);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 8); n++;
	XtSetArg(args[n], XmNy, 9); n++;
	XtSetArg(args[n], XmNwidth, 110); n++;
	XtSetArg(args[n], XmNheight, 131); n++;
	tmpLabelString = XmStringCreateLtoR("+/-", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_num_sign = XmCreatePushButton(Calc_Fo7_Fo11, "numbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_num_sign);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 475); n++;
	Calc_display = XmCreateTextField(Calc, "textField", args, n);
	XtManageChild(Calc_display);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 298); n++;
	XtSetArg(args[n], XmNwidth, 428); n++;
	XtSetArg(args[n], XmNeditable, FALSE ); n++;
	Calc_help = XmCreateTextField(Calc, "help", args, n);
	XtManageChild(Calc_help);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 4); n++;
	XtSetArg(args[n], XmNy, 66); n++;
	XtSetArg(args[n], XmNwidth, 39); n++;
	XtSetArg(args[n], XmNheight, 189); n++;
	XtSetArg(args[n], XmNshadowType,XmSHADOW_ETCHED_IN); n++;
	F_Calc_hexop= XmCreateFrame(Calc, "frame", args, n);
	XtManageChild(F_Calc_hexop);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 4); n++;
	XtSetArg(args[n], XmNy, 66); n++;
	XtSetArg(args[n], XmNwidth, 39); n++;
	XtSetArg(args[n], XmNheight, 189); n++;
	Calc_hexop = XmCreateForm(F_Calc_hexop, "rowColumn2", args, n);
	XtManageChild(Calc_hexop);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,1);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 39); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("&", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_hexop_pushButton2 = XmCreatePushButton(Calc_hexop, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_hexop_pushButton2);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,1);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,2);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 1); n++;
	XtSetArg(args[n], XmNwidth, 39); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("|", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_hexop_pushButton4 = XmCreatePushButton(Calc_hexop, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_hexop_pushButton4);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,2);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,3);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 2); n++;
	XtSetArg(args[n], XmNwidth, 39); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("^", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_hexop_pushButton12 = XmCreatePushButton(Calc_hexop, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_hexop_pushButton12);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,3);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,4);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNwidth, 39); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("<<", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_hexop_pushButton8 = XmCreatePushButton(Calc_hexop, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_hexop_pushButton8);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,4);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,5);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 4); n++;
	XtSetArg(args[n], XmNwidth, 39); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR(">>", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_hexop_pushButton6 = XmCreatePushButton(Calc_hexop, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_hexop_pushButton6);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,5);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 5); n++;
	XtSetArg(args[n], XmNwidth, 39); n++;
	XtSetArg(args[n], XmNheight, 184); n++;
	tmpLabelString = XmStringCreateLtoR("~", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_hexop_pushButton10 = XmCreatePushButton(Calc_hexop, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_hexop_pushButton10);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 183); n++;
	XtSetArg(args[n], XmNy, 66); n++;
	XtSetArg(args[n], XmNwidth, 64); n++;
	XtSetArg(args[n], XmNheight, 189); n++;
	XtSetArg(args[n], XmNshadowType,XmSHADOW_ETCHED_IN); n++;
	F_Calc_form111= XmCreateFrame(Calc, "frame", args, n);
	XtManageChild(F_Calc_form111);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 183); n++;
	XtSetArg(args[n], XmNy, 66); n++;
	XtSetArg(args[n], XmNwidth, 64); n++;
	XtSetArg(args[n], XmNheight, 189); n++;
	XtSetArg(args[n],XmNfractionBase ,6);n++;
	Calc_form111 = XmCreateForm(F_Calc_form111, "Form_13", args, n);
	XtManageChild(Calc_form111);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,1);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,3);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 3); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("+", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_form111_pushButton2 = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_form111_pushButton2);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNbottomPosition,1);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,3);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 3); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 61); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("-", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_form111_pushButton1 = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_form111_pushButton1);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,1);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,2);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,3);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 1); n++;
	XtSetArg(args[n], XmNwidth, 3); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("*", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_form111_pushButton3 = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_form111_pushButton3);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,1);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,2);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,3);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 3); n++;
	XtSetArg(args[n], XmNy, 1); n++;
	XtSetArg(args[n], XmNwidth, 61); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("/", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_form111_pushButton4 = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_form111_pushButton4);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,2);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,3);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,3);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 2); n++;
	XtSetArg(args[n], XmNwidth, 3); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("**", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_form111_pushButton8 = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_form111_pushButton8);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,3);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,4);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,3);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 3); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNwidth, 61); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("X", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_Xinput = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_Xinput);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,4);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,5);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n],XmNrightPosition,3);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_POSITION );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 4); n++;
	XtSetArg(args[n], XmNwidth, 3); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR("(", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_paropen = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_paropen);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,4);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNbottomPosition,5);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n],XmNleftPosition,3);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 3); n++;
	XtSetArg(args[n], XmNy, 4); n++;
	XtSetArg(args[n], XmNwidth, 61); n++;
	XtSetArg(args[n], XmNheight, 1); n++;
	tmpLabelString = XmStringCreateLtoR(")", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_parclose = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_parclose);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopPosition,5);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_POSITION );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 5); n++;
	XtSetArg(args[n], XmNwidth, 64); n++;
	XtSetArg(args[n], XmNheight, 184); n++;
	tmpLabelString = XmStringCreateLtoR(" = ", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_form111_pushButton17 = XmCreatePushButton(Calc_form111, "commbutton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_form111_pushButton17);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 410); n++;
	XtSetArg(args[n], XmNy, 33); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	tmpLabelString = XmStringCreateLtoR("QUIT ", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_pushButton19 = XmCreatePushButton(Calc, "quit", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_pushButton19);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 247); n++;
	XtSetArg(args[n], XmNy, 66); n++;
	XtSetArg(args[n], XmNwidth, 228); n++;
	XtSetArg(args[n], XmNmaxLength,36 ); n++;
	XtSetArg(args[n], XmNeditable, FALSE ); n++;
	Calc_result = XmCreateTextField(Calc, "textField1", args, n);
	XtManageChild(Calc_result);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 259); n++;
	XtSetArg(args[n], XmNy, 100); n++;
	tmpLabelString =  XmStringCreate("", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calculator_tri = XmCreateOptionMenu(Calc, "rowColumn1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calculator_tri);
	/* CREATE SUBWIDGETS */
	{
	Widget OptionPulldown;
	n=0;
	OptionPulldown = XmCreatePulldownMenu(Calculator_tri, "OptionSubmenu", NULL, 0);

	n=0;
	tmpLabelString =  XmStringCreate("Deg", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNalignment, 2 ); n++;
	Calculator_Error_E_cB131 = XmCreatePushButton(OptionPulldown, "cascadeButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calculator_Error_E_cB131);

	n=0;
	tmpLabelString =  XmStringCreate("Rad", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNalignment, 2 ); n++;
	Calculator_Error_E_cB141 = XmCreatePushButton(OptionPulldown, "cascadeButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calculator_Error_E_cB141);
	XtVaSetValues(Calculator_tri, XmNsubMenuId, OptionPulldown, NULL);
	XtVaSetValues(Calculator_tri, XmNsubMenuId, OptionPulldown, XmNmenuHistory, Calculator_Error_E_cB131, NULL);
}

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 334); n++;
	XtSetArg(args[n], XmNy, 100); n++;
	tmpLabelString =  XmStringCreate("", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_rowColumn318 = XmCreateOptionMenu(Calc, "rowColumn3", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_rowColumn318);
	/* CREATE SUBWIDGETS */
	{
	Widget OptionPulldown;
	n=0;
	OptionPulldown = XmCreatePulldownMenu(Calc_rowColumn318, "OptionSubmenu", NULL, 0);

	n=0;
	tmpLabelString =  XmStringCreate("signed", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_cascadeButton119 = XmCreatePushButton(OptionPulldown, "cascadeButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_cascadeButton119);

	n=0;
	tmpLabelString =  XmStringCreate("unsign", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_cascadeButton120 = XmCreatePushButton(OptionPulldown, "cascadeButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_cascadeButton120);
	XtVaSetValues(Calc_rowColumn318, XmNsubMenuId, OptionPulldown, NULL);
	XtVaSetValues(Calc_rowColumn318, XmNsubMenuId, OptionPulldown, XmNmenuHistory, Calc_cascadeButton119, NULL);
}

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 260); n++;
	XtSetArg(args[n], XmNy, 135); n++;
	tmpLabelString =  XmStringCreate("", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_edit = XmCreateOptionMenu(Calc, "rowColumn4", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_edit);
	/* CREATE SUBWIDGETS */
	{
	Widget OptionPulldown;
	n=0;
	XtSetArg(args[n], XmNresizeWidth, FALSE); n++;
	XtSetArg(args[n], XmNwidth, 100); n++;
	OptionPulldown = XmCreatePulldownMenu(Calc_edit, "OptionSubmenu", args, n);

	n=0;
	tmpLabelString =  XmStringCreate("ADD", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_cascadeButton234 = XmCreatePushButton(OptionPulldown, "cascadeButton2", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_cascadeButton234);

	n=0;
	tmpLabelString =  XmStringCreate("Insert", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_cascadeButton235 = XmCreatePushButton(OptionPulldown, "cascadeButton2", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_cascadeButton235);
	XtVaSetValues(Calc_edit, XmNsubMenuId, OptionPulldown, NULL);
	XtVaSetValues(Calc_edit, XmNsubMenuId, OptionPulldown, XmNmenuHistory, Calc_cascadeButton234, NULL);
}

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 423); n++;
	XtSetArg(args[n], XmNy, 105); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	tmpLabelString = XmStringCreateLtoR("Clear", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_clearall = XmCreatePushButton(Calc, "pushButton2", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_clearall);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 258); n++;
	XtSetArg(args[n], XmNy, 196); n++;
	XtSetArg(args[n], XmNwidth, 65); n++;
	XtSetArg(args[n], XmNheight, 99); n++;
	XtSetArg(args[n], XmNlistSizePolicy, XmCONSTANT); n++;
	XtSetArg(args[n], XmNselectionPolicy, XmSINGLE_SELECT); n++;
	Calc_functions = XmCreateScrolledList(Calc, "list1", args, n);
	XtManageChild(Calc_functions);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 331); n++;
	XtSetArg(args[n], XmNy, 196); n++;
	XtSetArg(args[n], XmNwidth, 54); n++;
	XtSetArg(args[n], XmNheight, 99); n++;
	XtSetArg(args[n], XmNlistSizePolicy, XmCONSTANT); n++;
	XtSetArg(args[n], XmNselectionPolicy, XmSINGLE_SELECT); n++;
	Calc_ownfunctions = XmCreateScrolledList(Calc, "list1", args, n);
	XtManageChild(Calc_ownfunctions);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 400); n++;
	XtSetArg(args[n], XmNy, 198); n++;
	XtSetArg(args[n], XmNwidth, 66); n++;
	XtSetArg(args[n], XmNheight, 97); n++;
	XtSetArg(args[n], XmNlistSizePolicy, XmCONSTANT); n++;
	XtSetArg(args[n], XmNselectionPolicy, XmSINGLE_SELECT); n++;
	Calc_const = XmCreateScrolledList(Calc, "list2", args, n);
	XtManageChild(Calc_const);
	MListAddString(Calc_const, "PI");
	MListAddString(Calc_const, "E");
	MListAddString(Calc_const, "RAN");
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 33); n++;
	XtSetArg(args[n], XmNwidth, 219); n++;
	XtSetArg(args[n], XmNheight, 27); n++;
	XtSetArg(args[n], XmNresizeHeight, FALSE ); n++;
	XtSetArg(args[n], XmNresizeWidth, FALSE); n++;
	 XtSetArg(args[n], XmNorientation, XmHORIZONTAL); n++;
	Calc_nummode = XmCreateRadioBox(Calc, "rowColumn",  args, n);
	XtManageChild(Calc_nummode);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 6); n++;
	XtSetArg(args[n], XmNy, 5); n++;
	tmpLabelString = XmStringCreateLtoR("DEZ", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNwidth, 49); n++;
	XtSetArg(args[n], XmNheight, 19); n++;
	XtSetArg(args[n], XmNalignment, 0 ); n++;
	XtSetArg(args[n], XmNset, TRUE ); n++; 
	XtSetArg(args[n],XmNbackground ,MGetPixel("green",parent));n++;
	Calc_numdez = XmCreateToggleButton(Calc_nummode, "toggleButton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_numdez);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 63); n++;
	XtSetArg(args[n], XmNy, 5); n++;
	tmpLabelString = XmStringCreateLtoR("HEX", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNwidth, 47); n++;
	XtSetArg(args[n], XmNheight, 19); n++;
	XtSetArg(args[n], XmNalignment, 0 ); n++;
	XtSetArg(args[n],XmNbackground ,MGetPixel("cyan",parent));n++;
	Calc_rowColumn5_toggleButton1 = XmCreateToggleButton(Calc_nummode, "toggleButton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_rowColumn5_toggleButton1);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 134); n++;
	XtSetArg(args[n], XmNy, 2); n++;
	tmpLabelString = XmStringCreateLtoR("OCT", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNwidth, 31); n++;
	XtSetArg(args[n], XmNheight, 22); n++;
	XtSetArg(args[n], XmNalignment, 0 ); n++;
	XtSetArg(args[n],XmNbackground ,MGetPixel("gold",parent));n++;
	Calc_rowColumn5_toggleButton2 = XmCreateToggleButton(Calc_nummode, "toggleButton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_rowColumn5_toggleButton2);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 189); n++;
	XtSetArg(args[n], XmNy, 5); n++;
	tmpLabelString = XmStringCreateLtoR("BIN", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNwidth, 31); n++;
	XtSetArg(args[n], XmNheight, 19); n++;
	XtSetArg(args[n], XmNalignment, 0 ); n++;
	XtSetArg(args[n],XmNbackground ,MGetPixel("indianred",parent));n++;
	Calc_rowColumn5_toggleButton3 = XmCreateToggleButton(Calc_nummode, "toggleButton", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_rowColumn5_toggleButton3);
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 236); n++;
	XtSetArg(args[n], XmNy, 33); n++;
	XtSetArg(args[n], XmNwidth, 173); n++;
	XtSetArg(args[n], XmNheight, 27); n++;
	XtSetArg(args[n], XmNresizeHeight, FALSE ); n++;
	XtSetArg(args[n], XmNresizeWidth, FALSE); n++;
	 XtSetArg(args[n], XmNorientation, XmHORIZONTAL); n++;
	Calc_mode = XmCreateRadioBox(Calc, "rowColumn1",  args, n);
	XtManageChild(Calc_mode);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 5); n++;
	XtSetArg(args[n], XmNy, 7); n++;
	tmpLabelString = XmStringCreateLtoR("Imm", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNwidth, 54); n++;
	XtSetArg(args[n], XmNheight, 17); n++;
	XtSetArg(args[n], XmNset, TRUE ); n++; 
	XtSetArg(args[n],XmNbackground ,MGetPixel("green",parent));n++;
	Calc_rowColumn110_TB11 = XmCreateToggleButton(Calc_mode, "immediate", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_rowColumn110_TB11);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 64); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	tmpLabelString = XmStringCreateLtoR("Form", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNwidth, 54); n++;
	XtSetArg(args[n], XmNheight, 21); n++;
	XtSetArg(args[n],XmNbackground ,MGetPixel("gold",parent));n++;
	Calc_form_mode = XmCreateToggleButton(Calc_mode, "formula", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_form_mode);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 129); n++;
	XtSetArg(args[n], XmNy, 4); n++;
	tmpLabelString = XmStringCreateLtoR("Pgm", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNwidth, 48); n++;
	XtSetArg(args[n], XmNheight, 20); n++;
	XtSetArg(args[n],XmNbackground ,MGetPixel("indianred",parent));n++;
	Calc_rowColumn110_TB33 = XmCreateToggleButton(Calc_mode, "program", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_rowColumn110_TB33);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 412); n++;
	XtSetArg(args[n], XmNy, 141); n++;
	tmpLabelString = XmStringCreateLtoR("Log", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	XtSetArg(args[n], XmNwidth, 54); n++;
	XtSetArg(args[n], XmNheight, 18); n++;
	Calc_logger = XmCreateToggleButton(Calc, "toggleButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_logger);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 260); n++;
	XtSetArg(args[n], XmNy, 178); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	XtSetArg(args[n], XmNalignment, 2 ); n++;
	tmpLabelString = XmStringCreateLtoR("int.    Functions   own", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_label124 = XmCreateLabel(Calc, "label1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_label124);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 405); n++;
	XtSetArg(args[n], XmNy, 177); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	XtSetArg(args[n], XmNalignment, 2 ); n++;
	tmpLabelString = XmStringCreateLtoR("Constant", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Calc_label229 = XmCreateLabel(Calc, "label2", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_label229);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 428); n++;
	XtSetArg(args[n], XmNy, 298); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	tmpLabelString = XmStringCreateLtoR("WizAnt", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
/* Label Pixmap */
/* pixmap at included */

	 {
#include "wizant.xpm"
		Pixmap LabelPixmap;
		int status;            /* XPM return status              */

		status = XpmCreatePixmapFromData(XtDisplay(parent), RootWindowOfScreen(XtScreen(parent)),
		               wizant, &LabelPixmap, NULL, NULL);
		if (status != XpmSuccess) LabelPixmap = (Pixmap) NULL;
		if (!(LabelPixmap)) XtWarning("Wrong pixmap: wizant.xpm");
		else {
		  XtSetArg(args[n], XmNlabelPixmap, LabelPixmap); n++;
		  XtSetArg(args[n], XmNlabelType, XmPIXMAP); n++;
		}
	}
	Calc_wizant = XmCreatePushButton(Calc, "wizant", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Calc_wizant);

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNbottomOffset ,0);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNbottomWidget,Calc_help);n++;
	XtSetValues(F_Calc_num, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNrightOffset ,0);n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNrightWidget,Calc_wizant);n++;
	XtSetValues(Calc_help, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,0);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,Calc_num);n++;
	XtSetValues(F_Calc_hexop, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,0);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,Calc_num);n++;
	XtSetArg(args[n],XmNbottomOffset ,0);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_OPPOSITE_WIDGET );n++;
	XtSetArg(args[n], XmNbottomWidget,Calc_hexop);n++;
	XtSetValues(F_Calc_form111, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,2);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,Calc_display);n++;
	XtSetValues(Calc_pushButton19, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,0);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_OPPOSITE_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,Calc_num);n++;
	XtSetArg(args[n],XmNleftOffset ,0);n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNleftWidget,Calc_form111);n++;
	XtSetValues(Calc_result, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,0);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,Calc_display);n++;
	XtSetValues(Calc_nummode, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,0);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,Calc_display);n++;
	XtSetValues(Calc_mode, args, n);

#endif
	XtAddCallback(Calc_display, XmNmodifyVerifyCallback,(XtCallbackProc)verifyinput_cb,(XtPointer)NULL );
	XtAddCallback(Calc_display, XmNvalueChangedCallback,(XtCallbackProc)inputvalchange_cb,(XtPointer)NULL );
	XtAddCallback(Calc_display, XmNactivateCallback,(XtCallbackProc)inputactivate_cb,(XtPointer)NULL );
	XtAddCallback(Calc_pushButton19, XmNactivateCallback,(XtCallbackProc)quit_cb,(XtPointer)NULL );
	XtAddCallback(Calc_result, XmNactivateCallback,(XtCallbackProc)result_cb,(XtPointer)NULL );
	XtAddCallback(Calc_clearall, XmNactivateCallback,(XtCallbackProc)clearall_cb,(XtPointer)NULL );
	XtAddCallback(Calc_functions, XmNsingleSelectionCallback,(XtCallbackProc)intfuncs_cb,(XtPointer)NULL );
	XtAddCallback(Calc_ownfunctions, XmNsingleSelectionCallback,(XtCallbackProc)ownselect_cb,(XtPointer)NULL );
	XtAddCallback(Calc_const, XmNsingleSelectionCallback,(XtCallbackProc)setconstant_cb,(XtPointer)NULL );
	XtAddCallback(Calc_logger, XmNvalueChangedCallback,(XtCallbackProc)logpr_cb,(XtPointer)NULL );
	XtAddCallback(Calc_rowColumn110_TB11, XmNvalueChangedCallback,(XtCallbackProc)setimmediate_cb,(XtPointer)NULL );
	XtAddCallback(Calc_form_mode, XmNvalueChangedCallback,(XtCallbackProc)setformula_cb,(XtPointer)NULL );
	XtAddCallback(Calc_rowColumn110_TB33, XmNvalueChangedCallback,(XtCallbackProc)setprogram_cb,(XtPointer)NULL );
	XtAddCallback(Calc_numdez, XmNvalueChangedCallback,(XtCallbackProc)setdecimal_cb,(XtPointer)NULL );
	XtAddCallback(Calc_rowColumn5_toggleButton1, XmNvalueChangedCallback,(XtCallbackProc)sethex_cb,(XtPointer)NULL );
	XtAddCallback(Calc_rowColumn5_toggleButton2, XmNvalueChangedCallback,(XtCallbackProc)setoctal_cb,(XtPointer)NULL );
	XtAddCallback(Calc_rowColumn5_toggleButton3, XmNvalueChangedCallback,(XtCallbackProc)setbinary_cb,(XtPointer)NULL );
	XtAddCallback(Calc_cascadeButton234, XmNactivateCallback,(XtCallbackProc)setaddmode_cb,(XtPointer)NULL );
	XtAddCallback(Calc_cascadeButton235, XmNactivateCallback,(XtCallbackProc)setinsertmode_cb,(XtPointer)NULL );
	XtAddCallback(Calc_cascadeButton119, XmNactivateCallback,(XtCallbackProc)setsigned_cb,(XtPointer)NULL );
	XtAddCallback(Calc_cascadeButton120, XmNactivateCallback,(XtCallbackProc)setunsigned_cb,(XtPointer)NULL );
	XtAddCallback(Calculator_Error_E_cB131, XmNactivateCallback,(XtCallbackProc)setdegmode_cb,(XtPointer)NULL );
	XtAddCallback(Calculator_Error_E_cB141, XmNactivateCallback,(XtCallbackProc)setradmode_cb,(XtPointer)NULL );
	XtAddCallback(Calc_form111_pushButton2, XmNactivateCallback,(XtCallbackProc)bplus_cb,(XtPointer)NULL );
	XtAddCallback(Calc_form111_pushButton1, XmNactivateCallback,(XtCallbackProc)bmin_cb,(XtPointer)NULL );
	XtAddCallback(Calc_form111_pushButton3, XmNactivateCallback,(XtCallbackProc)bmal_cb,(XtPointer)NULL );
	XtAddCallback(Calc_form111_pushButton4, XmNactivateCallback,(XtCallbackProc)bdiv_cb,(XtPointer)NULL );
	XtAddCallback(Calc_form111_pushButton8, XmNactivateCallback,(XtCallbackProc)bpotenz_cb,(XtPointer)NULL );
	XtAddCallback(Calc_Xinput, XmNactivateCallback,(XtCallbackProc)bX_cb,(XtPointer)NULL );
	XtAddCallback(Calc_paropen, XmNactivateCallback,(XtCallbackProc)bopenpar_cb,(XtPointer)NULL );
	XtAddCallback(Calc_parclose, XmNactivateCallback,(XtCallbackProc)bclospar_cb,(XtPointer)NULL );
	XtAddCallback(Calc_form111_pushButton17, XmNactivateCallback,(XtCallbackProc)bequal_cb,(XtPointer)NULL );
	XtAddCallback(Calc_hexop_pushButton2, XmNactivateCallback,(XtCallbackProc)band_cb,(XtPointer)NULL );
	XtAddCallback(Calc_hexop_pushButton4, XmNactivateCallback,(XtCallbackProc)bor_cb,(XtPointer)NULL );
	XtAddCallback(Calc_hexop_pushButton12, XmNactivateCallback,(XtCallbackProc)bxor_cb,(XtPointer)NULL );
	XtAddCallback(Calc_hexop_pushButton8, XmNactivateCallback,(XtCallbackProc)blshift_cb,(XtPointer)NULL );
	XtAddCallback(Calc_hexop_pushButton6, XmNactivateCallback,(XtCallbackProc)brshift_cb,(XtPointer)NULL );
	XtAddCallback(Calc_hexop_pushButton10, XmNactivateCallback,(XtCallbackProc)bnot_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_7, XmNactivateCallback,(XtCallbackProc)b7_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_8, XmNactivateCallback,(XtCallbackProc)b8_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_9, XmNactivateCallback,(XtCallbackProc)b9_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_4, XmNactivateCallback,(XtCallbackProc)b4_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_5, XmNactivateCallback,(XtCallbackProc)b5_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_6, XmNactivateCallback,(XtCallbackProc)b6_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_1, XmNactivateCallback,(XtCallbackProc)b1_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_2, XmNactivateCallback,(XtCallbackProc)b2_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_3, XmNactivateCallback,(XtCallbackProc)b3_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_0, XmNactivateCallback,(XtCallbackProc)b0_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_point, XmNactivateCallback,(XtCallbackProc)bdot_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_sign, XmNactivateCallback,(XtCallbackProc)signchange_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_hex_D, XmNactivateCallback,(XtCallbackProc)bd_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_hex_A, XmNactivateCallback,(XtCallbackProc)ba_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_E, XmNactivateCallback,(XtCallbackProc)be_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_C, XmNactivateCallback,(XtCallbackProc)bc_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_F, XmNactivateCallback,(XtCallbackProc)bf_cb,(XtPointer)NULL );
	XtAddCallback(Calc_num_hex_B, XmNactivateCallback,(XtCallbackProc)bb_cb,(XtPointer)NULL );
  /* Finit-functions */

/* starting in Decimal mode */
	setdeztype();
	SetColorbyName(Calc_nummode,XmNbackground ,"green");  /* decimal isa green */
	makeposscomm();
	if(calcmode == 0)
		 SetColorbyName(Calc_mode,XmNbackground ,"green");
	else if (calcmode == 1) 
		 SetColorbyName(Calc_mode,XmNbackground ,"gold");
	else 
		 SetColorbyName(Calc_mode,XmNbackground ,"red");
/* as default is immediate mode, set parenthesis insensitive */
 	XtSetSensitive(Calc_paropen,FALSE);
 	XtSetSensitive(Calc_parclose,FALSE);

	XtSetSensitive(Calc_functions,FALSE);
	XtSetSensitive(Calc_ownfunctions,FALSE);

/* set internal functions to list */
  {
     int i,typval;
     FILE *savefile;
     char savepath[100],string[500] ,*equ,*typ;

	for(i=0;i<nfunctions;i++)
	  {
		MListAddString(Calc_functions,funcs[i]. funcname);
	  }
	strcpy(savepath,getenv("HOME"));
	strcat(savepath,"/"OWNcodefile);
	
	if((savefile = fopen(savepath,"r")))
	  {
	     while (fgets(string,499,savefile) )
	      {
		equ = strchr(string,'=');
		equ++;				/* terminate string after equal */
		*equ = 0;
		equ = strchr(++equ,'%');
		typ = strchr(equ,'(');
		typ++;
		sscanf(typ,"%d",&typval);
		equ[4]=0;
		allocateownfunc(NownFunct++,string , equ,typval);
		if(NownFunct >= MAXownFunct)
			break;
	      }
	     fclose(savefile);
	     display_allowncode();
	  }
editcursor = XCreateFontCursor(XtDisplay(Calc_ownfunctions), XC_question_arrow); 
delcursor = XCreateFontCursor(XtDisplay(Calc_ownfunctions), XC_pirate); 

  }
/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("toggle sign of selected area (decimal only)");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_num_sign, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_num_sign, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Displays Input and Result");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_display, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_display, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("AND");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_hexop_pushButton2, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_hexop_pushButton2, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("OR");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_hexop_pushButton4, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_hexop_pushButton4, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("XOR");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_hexop_pushButton12, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_hexop_pushButton12, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("left shift, if shift count greater 32 cyclic shift");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_hexop_pushButton8, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_hexop_pushButton8, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("right shift, if shift count greater 32 cyclic shift");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_hexop_pushButton6, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_hexop_pushButton6, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("NOT either inverts the highlighted or acts as Function");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_hexop_pushButton10, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_hexop_pushButton10, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("x ** n");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_form111_pushButton8, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_form111_pushButton8, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("in programming mode dummy argument of function");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_Xinput, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_Xinput, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("open parenthesis");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_paropen, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_paropen, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("close parenthesis");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_parclose, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_parclose, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("equal   force calculation");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_form111_pushButton17, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_form111_pushButton17, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Display of actual or intermediate Result klick+return adds it to Input");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_result, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_result, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Select trigonometric as Degree or Radiants");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calculator_tri, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calculator_tri, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Select Signed or Unsigned for Shift Functions");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_rowColumn318, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_rowColumn318, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("set integer to signed (shift!!)");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_cascadeButton119, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_cascadeButton119, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("set integer to unsigned (shift)");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_cascadeButton120, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_cascadeButton120, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Change Position, where button press shall insert (or add)");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_edit, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_edit, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("all inputs by buttons are added at end to input field");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_cascadeButton234, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_cascadeButton234, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("all button press are inserted at cursorpostion of input field");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_cascadeButton235, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_cascadeButton235, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Actual system Functions, Klick to insert");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_functions, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_functions, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Actual system Functions, Klick to insert");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_ownfunctions, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_ownfunctions, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Klick on Constant name to add into Input");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_const, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_const, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Select DataMode");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_nummode, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_nummode, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Set Decimal notation and double");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_numdez, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_numdez, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Set Hexadecimal notation and Integer");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_rowColumn5_toggleButton1, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_rowColumn5_toggleButton1, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Set Octal Notation and Integer");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_rowColumn5_toggleButton2, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_rowColumn5_toggleButton2, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Set Binary notation and Integer");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_rowColumn5_toggleButton3, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_rowColumn5_toggleButton3, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Mode of Calculation and Input");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_mode, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_mode, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Immediate calculation mode ");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_rowColumn110_TB11, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_rowColumn110_TB11, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Equation Mode (Result at = )");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_form_mode, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_form_mode, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Program Mode (store all Input as Function)");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_rowColumn110_TB33, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_rowColumn110_TB33, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Activate Logprint");
	data->Qhelp_widget = Calc_help;
	XtAddEventHandler(Calc_logger, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Calc_logger, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }
	XtManageChild(Calc);
	return Calc;
}

/***************************************************************************
 ***************************************************************************
 *
 *  Dialog function:	DI3
 *
 ***************************************************************************
 *  
 *  Input:		
 *
 *  Return:		Widget DI3
 *
 *  Documentation:	<Insert documentation here>
 *
 *  
 *  History:		Thu May 16 14:03:40 2002

 *
 *
 ***************************************************************************
 ***************************************************************************/

Widget Error_E_Create (Widget parent ,char *message){
  Arg args[40]; 
  Cardinal n;
  XmString tmpLabelString = NULL;
  Widget MainShell;
Widget Error_pushButton11;
	n = 0;
	XtSetArg(args[n], XmNwidth, 387); n++;
	XtSetArg(args[n], XmNheight, 68); n++;
	XtSetArg(args[n], XmNtitle, "Calculator Error"); n++;
	XtSetArg(args[n], XmNautoUnmanage, FALSE); n++;
	MainShell = (Widget)XmCreateDialogShell(XtParent(parent),"form1_Dialog",args, n);

	n = 0;
	 XtSetArg(args[n], XmNwidth, 387); n++;
	XtSetArg(args[n], XmNheight, 68); n++;
	XtSetArg(args[n], XmNautoUnmanage, FALSE); n++;
	XtSetArg(args[n], XmNnoResize, FALSE); n++;
	XtSetArg(args[n], XmNdefaultPosition, TRUE); n++;
	Error_E = XmCreateForm(MainShell, "form1", args, n);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 387); n++;
	XtSetArg(args[n], XmNeditable, FALSE ); n++;
	Error_error = XmCreateTextField(Error_E, "error", args, n);
	XtManageChild(Error_error);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 171); n++;
	XtSetArg(args[n], XmNy, 35); n++;
	XtSetArg(args[n], XmNwidth, 57); n++;
	XtSetArg(args[n], XmNheight, 29); n++;
	tmpLabelString = XmStringCreateLtoR("QUIT", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Error_pushButton11 = XmCreatePushButton(Error_E, "pushButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Error_pushButton11);
	XtAddCallback(Error_error, XmNvalueChangedCallback,(XtCallbackProc)errorbell_xb,(XtPointer)NULL );
	XtAddCallback(Error_pushButton11, XmNactivateCallback,(XtCallbackProc)Errorquit_cb,(XtPointer)NULL );
  /* Finit-functions */
 	XmTextFieldSetString(Error_error , message);
	XtManageChild(Error_E);
	XtManageChild(MainShell);
	return Error_E;
}

/*************************************************************************** 
 * 
 * Funktionsname:	own_Create
 * 
 * 
 * Input:		Widget parent
 * 
 * Return:		Widget 
 * 
 * Dokumentation:		
 * 
 * 
 ***************************************************************************/

static Widget own_Create (Widget parent ){
  Arg args[40]; 
  Cardinal n;
  XmString tmpLabelString = NULL;
  Widget MainShell;
  Widget own;
Widget own_pushButton23;
Widget own_pushButton12;
Widget own_pushButton313;
Widget own_textField10;
Widget own_cascadeButton110;
Widget own_cascadeButton111;
Widget own_cascadeButton212;
Widget own_label16;
Widget own_label27;
Widget own_label38;
	n = 0;
	XtSetArg(args[n], XmNwidth, 359); n++;
	XtSetArg(args[n], XmNheight, 142); n++;
	XtSetArg(args[n], XmNtitle, "Own Functions"); n++;
	XtSetArg(args[n], XmNautoUnmanage, FALSE); n++;
{
  Dimension   xw,yh;
  Arg pargs[10];
  Cardinal pn;	
	pn=0;
	XtSetArg(pargs[pn],XmNx , &xw);pn++;
	XtSetArg(pargs[pn],XmNy , &yh);pn++;
	XtGetValues(XtParent(parent) , pargs,pn);
	XtSetArg(args[n], XmNx, xw+0); n++;
	XtSetArg(args[n], XmNy, yh+0); n++; 
}
	MainShell = (Widget)XmCreateDialogShell(XtParent(parent),"form2_Dialog",args, n);

	n = 0;
	 XtSetArg(args[n], XmNwidth, 359); n++;
	XtSetArg(args[n], XmNheight, 142); n++;
	XtSetArg(args[n], XmNautoUnmanage, FALSE); n++;
	XtSetArg(args[n], XmNnoResize, FALSE); n++;
	XtSetArg(args[n], XmNdefaultPosition, FALSE); n++;
	own = XmCreateForm(MainShell, "form2", args, n);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 12); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	tmpLabelString = XmStringCreateLtoR("Test", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_pushButton23 = XmCreatePushButton(own, "pushButton2", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_pushButton23);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 56); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	tmpLabelString = XmStringCreateLtoR("SAVE", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_pushButton12 = XmCreatePushButton(own, "pushButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_pushButton12);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 12); n++;
	XtSetArg(args[n], XmNy, 28); n++;
	XtSetArg(args[n], XmNwidth, 35); n++;
	XtSetArg(args[n], XmNheight, 26); n++;
	tmpLabelString = XmStringCreateLtoR("quit", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_pushButton313 = XmCreatePushButton(own, "quit", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_pushButton313);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 109); n++;
	XtSetArg(args[n], XmNwidth, 359); n++;
	XtSetArg(args[n], XmNeditable, FALSE ); n++;
	own_textField10 = XmCreateTextField(own, "help", args, n);
	XtManageChild(own_textField10);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 2); n++;
	XtSetArg(args[n], XmNy, 70); n++;
	XtSetArg(args[n], XmNwidth, 144); n++;
	own_input = XmCreateTextField(own, "textField2", args, n);
	XtManageChild(own_input);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 213); n++;
	XtSetArg(args[n], XmNy, 70); n++;
	XtSetArg(args[n], XmNwidth, 144); n++;
	XtSetArg(args[n], XmNeditable, FALSE ); n++;
	own_result = XmCreateTextField(own, "textField3", args, n);
	XtManageChild(own_result);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 239); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	tmpLabelString =  XmStringCreate("Mode", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_mode = XmCreateOptionMenu(own, "rowColumn1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_mode);
	/* CREATE SUBWIDGETS */
	{
	Widget OptionPulldown;
	n=0;
	OptionPulldown = XmCreatePulldownMenu(own_mode, "OptionSubmenu", NULL, 0);

	n=0;
	tmpLabelString =  XmStringCreate("Pgm", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_cascadeButton110 = XmCreatePushButton(OptionPulldown, "cascadeButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_cascadeButton110);

	n=0;
	tmpLabelString =  XmStringCreate("Edit", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_cascadeButton111 = XmCreatePushButton(OptionPulldown, "cascadeButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_cascadeButton111);

	n=0;
	tmpLabelString =  XmStringCreate("Delete", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_cascadeButton212 = XmCreatePushButton(OptionPulldown, "cascadeButton2", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_cascadeButton212);
	XtVaSetValues(own_mode, XmNsubMenuId, OptionPulldown, NULL);
	XtVaSetValues(own_mode, XmNsubMenuId, OptionPulldown, XmNmenuHistory, own_cascadeButton110, NULL);
}

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 142); n++;
	XtSetArg(args[n], XmNy, 20); n++;
	XtSetArg(args[n], XmNwidth, 72); n++;
	own_name = XmCreateTextField(own, "textField1", args, n);
	XtManageChild(own_name);
	XmTextSetString(own_name, "%nam");

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 56); n++;
	XtSetArg(args[n], XmNy, 53); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	XtSetArg(args[n], XmNalignment, 2 ); n++;
	tmpLabelString = XmStringCreateLtoR("Input Value", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_label16 = XmCreateLabel(own, "label1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_label16);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 256); n++;
	XtSetArg(args[n], XmNy, 53); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	XtSetArg(args[n], XmNalignment, 2 ); n++;
	tmpLabelString = XmStringCreateLtoR("Result", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_label27 = XmCreateLabel(own, "label2", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_label27);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 128); n++;
	XtSetArg(args[n], XmNy, 3); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	XtSetArg(args[n], XmNalignment, 2 ); n++;
	tmpLabelString = XmStringCreateLtoR("Functions Name", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	own_label38 = XmCreateLabel(own, "label3", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(own_label38);

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,2);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,own_pushButton23);n++;
	XtSetValues(own_pushButton313, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,0);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,own_label38);n++;
	XtSetValues(own_name, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNbottomOffset ,0);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNbottomWidget,own_input);n++;
	XtSetValues(own_label16, args, n);

#endif

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNbottomOffset ,0);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNbottomWidget,own_result);n++;
	XtSetValues(own_label27, args, n);

#endif
	XtAddCallback(own_pushButton23, XmNactivateCallback,(XtCallbackProc)test_cb,(XtPointer)NULL );
	XtAddCallback(own_pushButton12, XmNactivateCallback,(XtCallbackProc)saveowncode_cb,(XtPointer)NULL );
	XtAddCallback(own_pushButton313, XmNactivateCallback,(XtCallbackProc)pgmquit_cb,(XtPointer)NULL );
	XtAddCallback(own_cascadeButton110, XmNactivateCallback,(XtCallbackProc)pgmsubpgm_cb,(XtPointer)NULL );
	XtAddCallback(own_cascadeButton111, XmNactivateCallback,(XtCallbackProc)pgmsubedit_cb,(XtPointer)NULL );
	XtAddCallback(own_cascadeButton212, XmNactivateCallback,(XtCallbackProc)pgmsubdel_cb,(XtPointer)NULL );
/* DI4 FINIT-function*/
XmTextFieldSetString(own_result,""); 
XmTextFieldSetString(own_input,""); 
XmTextFieldSetString(own_name,""); 

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Press will require an inputvalue and execute the function");
	data->Qhelp_widget = own_textField10;
	XtAddEventHandler(own_pushButton23, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(own_pushButton23, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("SAVE will add this function to the owncode stack and write it out");
	data->Qhelp_widget = own_textField10;
	XtAddEventHandler(own_pushButton12, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(own_pushButton12, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("The Value herein will be used as input");
	data->Qhelp_widget = own_textField10;
	XtAddEventHandler(own_input, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(own_input, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Displayed Result from Test");
	data->Qhelp_widget = own_textField10;
	XtAddEventHandler(own_result, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(own_result, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Pgm for new Functions, Edit to modify , or Delete a stored, klick it in main Window");
	data->Qhelp_widget = own_textField10;
	XtAddEventHandler(own_mode, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(own_mode, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Klick Function in main Window to edit");
	data->Qhelp_widget = own_textField10;
	XtAddEventHandler(own_cascadeButton111, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(own_cascadeButton111, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Klick in function list to delete ");
	data->Qhelp_widget = own_textField10;
	XtAddEventHandler(own_cascadeButton212, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(own_cascadeButton212, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Name of actual Function (must start with %)");
	data->Qhelp_widget = own_textField10;
	XtAddEventHandler(own_name, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(own_name, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }
	XtManageChild(own);
	XtManageChild(MainShell);
	return own;
}

/*************************************************************************** 
 * 
 * Funktionsname:	Logprint_Create
 * 
 * 
 * Input:		Widget parent
 * 
 * Return:		Widget 
 * 
 * Dokumentation:		
 * 
 * 
 ***************************************************************************/

static Widget Logprint_Create (Widget parent ){
  Arg args[40]; 
  Cardinal n;
  XmString tmpLabelString = NULL;
  Widget MainShell;
  Widget Logprint;
Widget Logprint_textField11;
Widget Logprint_pushButton13;
Widget Logprint_pushButton24;
Widget Logprint_pushButton36;
	n = 0;
	XtSetArg(args[n], XmNwidth, 270); n++;
	XtSetArg(args[n], XmNheight, 260); n++;
	XtSetArg(args[n], XmNtitle, "Log print"); n++;
	XtSetArg(args[n], XmNautoUnmanage, FALSE); n++;
	MainShell = (Widget)XmCreateDialogShell(XtParent(parent),"form3_Dialog",args, n);

	n = 0;
	 XtSetArg(args[n], XmNwidth, 270); n++;
	XtSetArg(args[n], XmNheight, 260); n++;
	XtSetArg(args[n], XmNautoUnmanage, FALSE); n++;
	XtSetArg(args[n], XmNnoResize, TRUE); n++;
	XtSetArg(args[n], XmNdefaultPosition, TRUE); n++;
	Logprint = XmCreateForm(MainShell, "form3", args, n);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 227); n++;
	XtSetArg(args[n], XmNwidth, 270); n++;
	XtSetArg(args[n], XmNeditable, FALSE ); n++;
	Logprint_textField11 = XmCreateTextField(Logprint, "help", args, n);
	XtManageChild(Logprint_textField11);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 178); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNwidth, 92); n++;
	Logprint_printer = XmCreateTextField(Logprint, "textField1", args, n);
	XtManageChild(Logprint_printer);
	XmTextSetString(Logprint_printer, "lpr ");

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_FORM );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_FORM );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 33); n++;
	XtSetArg(args[n], XmNeditMode, XmMULTI_LINE_EDIT ); n++;
	XtSetArg(args[n], XmNwidth, 270); n++;
	XtSetArg(args[n], XmNheight, 194); n++;
	XtSetArg(args[n], XmNscrollHorizontal, FALSE); n++;
	XtSetArg(args[n], XmNscrollVertical, TRUE); n++;
	Logprint_log = XmCreateScrolledText(Logprint, "text1", args, n);
	XtManageChild(Logprint_log);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 0); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	tmpLabelString = XmStringCreateLtoR("Quit", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Logprint_pushButton13 = XmCreatePushButton(Logprint, "pushButton1", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Logprint_pushButton13);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 49); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	tmpLabelString = XmStringCreateLtoR("Print", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Logprint_pushButton24 = XmCreatePushButton(Logprint, "pushButton2", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Logprint_pushButton24);

	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNleftAttachment, XmATTACH_SELF );n++;
	XtSetArg(args[n], XmNrightAttachment, XmATTACH_SELF );n++;
#endif
	 XtSetArg(args[n], XmNx, 101); n++;
	XtSetArg(args[n], XmNy, 0); n++;
	XtSetArg(args[n], XmNrecomputeSize, TRUE ); n++;
	tmpLabelString = XmStringCreateLtoR("Clear", XmFONTLIST_DEFAULT_TAG);
	XtSetArg(args[n], XmNlabelString, tmpLabelString); n++;
	Logprint_pushButton36 = XmCreatePushButton(Logprint, "pushButton3", args, n);
	XmStringFree(tmpLabelString);
	XtManageChild(Logprint_pushButton36);

/*   Generate additional attachments   */
	n=0;
#ifndef LESSTIFF
	XtSetArg(args[n],XmNtopOffset ,0);n++;
	XtSetArg(args[n], XmNtopAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNtopWidget,Logprint_printer);n++;
	XtSetArg(args[n],XmNbottomOffset ,0);n++;
	XtSetArg(args[n], XmNbottomAttachment, XmATTACH_WIDGET );n++;
	XtSetArg(args[n], XmNbottomWidget,Logprint_textField11);n++;
	XtSetValues(XtParent(Logprint_log), args, n);

#endif
	XtAddCallback(Logprint_pushButton13, XmNactivateCallback,(XtCallbackProc)logquit_cb,(XtPointer)NULL );
	XtAddCallback(Logprint_pushButton24, XmNactivateCallback,(XtCallbackProc)log_print_cb,(XtPointer)NULL );
	XtAddCallback(Logprint_pushButton36, XmNactivateCallback,(XtCallbackProc)log_clear_cb,(XtPointer)NULL );
  /* Finit-functions */
logger = Logprint_log;
/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Printer commando");
	data->Qhelp_widget = Logprint_textField11;
	XtAddEventHandler(Logprint_printer, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Logprint_printer, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Hides the dialog");
	data->Qhelp_widget = Logprint_textField11;
	XtAddEventHandler(Logprint_pushButton13, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Logprint_pushButton13, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }

/* QUICKHELP - HANDLER */
  {    USER_DATA *data;
	data = (USER_DATA *) malloc(sizeof(USER_DATA));
	data->Qhelp_name = strdup("Prints the Log and clears it");
	data->Qhelp_widget = Logprint_textField11;
	XtAddEventHandler(Logprint_pushButton24, EnterWindowMask, FALSE, (XtEventHandler) MSetQuickhelp, (XtPointer)data);
	XtAddCallback(Logprint_pushButton24, XmNdestroyCallback, (XtCallbackProc) MDestroyQuickhelp, (XtPointer)data);
  }
	XtManageChild(Logprint);
	XtManageChild(MainShell);
	return Logprint;
}

/*	CALLBACKS */
static void bd_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("D");
}
static void ba_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("A");
}
static void be_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("E");
}
static void bc_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("C");
}
static void bf_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("F");
}
static void bb_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("B");
}
static void b7_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("7");
}
static void b8_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("8");
}
static void b9_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("9");
}
static void b4_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("4");
}
static void b5_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("5");
}
static void b6_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("6");
}
static void b1_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("1");
}
static void b2_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("2");
}
static void b3_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("3");
}
static void b0_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

		dobutton("0");
}
static void bdot_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton(".");
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	signchange_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmPushButtonCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	take the selected part of input and inverts the sign
 *			redisplaying the new value
 *
 *
 *  History:		Sat Dec 30 11:33:45 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void signchange_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

    char *selstring , item[80]="";
    XmTextPosition leftpos,rightpos;
    double val;
    long int ival;
    int i;

	if(!(selstring = XmTextFieldGetSelection (Calc_display)))
	  { 
	     dobutton("-");
	     return;
	  }
	switch (datatype)
	  {
		case DECIMAL:
		sscanf(selstring,"%lf",&val);
		val = -val;
		printdec(item,val);
		break;
		case HEX:
		ival = -decodeint(selstring);
		sprintf(item,"%lx",ival);
		break;
		case OCTAL:
		ival = -decodeint(selstring);
		sprintf(item,"%lo",ival);
		break;
		case BINARY:
		ival = -decodeint(selstring);
		for(i=0;i<32;i++,ival<<= 1)
		 {
		   if(ival & 0x80000000) strcat(item,"1");
		   else  strcat(item,"0");
		 }
		break;
	  }
	XmTextFieldGetSelectionPosition (Calc_display, &leftpos, &rightpos);
	XmTextFieldReplace (Calc_display,leftpos,rightpos,item);
	XtFree(selstring);	
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	verifyinput_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmTextVerifyCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	verifies the input in comparision to actual mode
 *
 *
 *  History:		Wed Dec 27 16:46:26 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void verifyinput_cb (Widget parent, XtPointer data, XmTextVerifyCallbackStruct *cbs) {
   int length;
   char *input;
	cbs->doit =TRUE;
	if(!cbs->text->length) return ;  /* was a delete */
	length = cbs->text->length;
	input  = cbs->text->ptr;

	while(length > 0)
	 {
	    if(*input != 'X' )
	    {
	      
	    switch (datatype)
	     {
		case HEX:
		 if(!isxdigit(*input))
			if(!(cbs->doit = maycommand (input,length)))return;
		 break;
		case OCTAL:
		 if(!isdigit(*input) || *input > '7')
			if(!(cbs->doit = maycommand (input,length)))return;
		 break;
		case BINARY:
		 if(!isdigit(*input) || *input > '1')
			if(!(cbs->doit = maycommand (input,length)))return;
		 break;
		case DECIMAL:		/* might be e-99   format */
		 if(!isdigit(*input) && *input != '.' && *input != 'e')
			if(!(cbs->doit = maycommand (input,length)))return;
		 break;
	      }
	    if(cbs->doit && *input == '%')
		{			/* assume three chars after % sign */
		     length -= 3;
		     input +=  3;
		}
	   }
	   else if(calcmode != 2)
		cbs->doit = FALSE;
	   length--;
	   input++;
	 }

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	inputvalchange_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmTextVerifyCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	if immediate mode selected, checks for enough commands 
 *			to do calcultation and does it
 *
 *
 *  History:		Sat Dec 30 09:31:34 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void inputvalchange_cb (Widget parent, XtPointer data, XmTextVerifyCallbackStruct *cbs) {
   char *input , *output ,*check;

	if(calcmode == 1)			
	  {		/* formula mode   do it */
		check = input = XmTextFieldGetString(parent);
		if(!strchr(input,'='))
   		  {			/* for formula we need an equal sign */
			XtFree(input);
	  		return;
	  	  }
		if(countparenth(input))
			calcformula(&input , Calc_result);
		input = strchr(check,'=');

		*input = 0;			/* delete leading = */
		 XmTextFieldSetString (parent,check);
		XtFree(check); 
	  	return;
	  }
	else if(calcmode == 2) return;    /* Program mode not yet */

/* only in immediate mode check for execution */

	check = input = XmTextFieldGetString(parent);
	nactcomm = 0;
	while (TRUE)
	  {
		if((check = strpbrk(check,posscommands)))
		  {
			if(check == input)	/* just a sign as first char */
			   {
			      check++;
			      continue;
			   }
 			if(*check == '=' || (*check != '~' && nactcomm++) )
		 	 {
		 	   output = execute_immediate(input);
			   if(output)
				 XmTextFieldInsert (parent
				   ,XmTextGetLastPosition (parent),output);
			    XtFree(input);
			   return;
		  	 }
		    	if(check[0] == check[1])
				check++;
			check++;
		
		  }
		else
		  {
			XtFree(input);
			return;
		  }
	  }

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	inputactivate_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmTextVerifyCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	just adds a = at end
 *
 *
 *  History:		Sat Dec 30 11:34:38 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void inputactivate_cb (Widget parent, XtPointer data, XmTextVerifyCallbackStruct *cbs) {
	 XmTextFieldInsert (parent,XmTextGetLastPosition (parent),"=");

}
static void band_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("&");
}
static void bor_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("|");
}
static void bxor_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("^");
}
static void blshift_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("<");
}
static void brshift_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton(">");
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	bnot_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmPushButtonCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	if a field is selected, inverts it, else pushes the
 *			~ into input display
 *
 *
 *  History:		Sat Dec 30 11:28:42 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void bnot_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

    char *selstring , item[80]="";
    XmTextPosition leftpos,rightpos;
    long int ival;
    int i;

	if(!(selstring = XmTextFieldGetSelection (Calc_display))) 
	  {
	    dobutton("~");
	    return;
	  }

	switch (datatype)
	  {
		case HEX:
		ival = decodeint(selstring);
		ival = ~ival;
		sprintf(item,"%lx",ival);
		break;
		case OCTAL:
		ival = decodeint(selstring);
		ival = ~ival;
		sprintf(item,"%lo",ival);
		break;
		case BINARY:
		ival = decodeint(selstring);
		ival = ~ival;
		
		for(i=0;i<32;i++,ival<<= 1)
		 {
		   if(ival & 0x80000000) strcat(item,"1");
		   else  strcat(item,"0");
		 }
		break;
	  }
	XmTextFieldGetSelectionPosition (Calc_display, &leftpos, &rightpos);
	XmTextFieldReplace (Calc_display,leftpos,rightpos,item);
	XtFree(selstring);	

}
static void bplus_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("+");
}
static void bmin_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("-");
}
static void bmal_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("*");
}
static void bdiv_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("/");
}
static void bpotenz_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("**");
}
static void bX_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	if(calcmode == 2)
		dobutton("X");
}
static void bopenpar_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton("(");
}
static void bclospar_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	dobutton(")");
}
static void bequal_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	XmTextFieldInsert (Calc_display,XmTextGetLastPosition (Calc_display)
			,"=");
}
static void quit_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	MCloseDialog(parent);
}
static void result_cb (Widget parent, XtPointer data , XmTextVerifyCallbackStruct * cbs ){

	XmTextFieldInsert (Calc_display,XmTextGetLastPosition (Calc_display)
	,XmTextFieldGetString(parent));
	
}
static void setdegmode_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	trigmode = 0;
}
static void setradmode_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	trigmode = 1;
}
static void setsigned_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	signmode = 1;
}
static void setunsigned_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	signmode = 0;
}
static void setaddmode_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	insertmode = 0;
}
static void setinsertmode_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	insertmode = 1;
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	clearall_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmPushButtonCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	clear input  field
 *
 *
 *  History:		Thu Dec 28 15:31:32 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void clearall_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	XmTextFieldSetString(Calc_display,""); 
	XtSetSensitive(Calc_numdez,TRUE);
}
static void intfuncs_cb (Widget parent, XtPointer data , XmListCallbackStruct * cbs ){

   char function[30] = "%";
    int pos;
	pos = MListGetPosition(parent);
 	if(pos <= 0 )return;

	strcpy(function,MListGetString(parent));
	strcat(function,"(");
	dobutton(function);
	XmListDeselectPos(parent,pos);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	ownselect_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmListCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	depending on the global programmode copies the functionname
 *			(normal) into input display, copies the function code to
 *			inputdisplay (overwriting) or deletes the selected function
 *
 *
 *  History:		Wed Jan 17 17:20:37 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void ownselect_cb (Widget parent, XtPointer data , XmListCallbackStruct * cbs ){

   char *name , *locstring,*equ;
   int index;
    int pos;
	pos = MListGetPosition(parent);
 	if(pos <= 0 )return;


	name = MListGetString(parent);
	XmListDeselectPos(parent,pos);
	switch(programmode )
	  {
		case 1:		/* edit mode */
		  index = getownfunction(name);
		  if(index < 0 ) break;
		  locstring = (char *)malloc(strlen(OWNfuncts[index].code)+2);
		  strcpy(locstring,OWNfuncts[index].code);
		  equ = strchr(locstring,'=');
		  *equ = 0;		/* cut equal sign */
	 	  XmTextFieldSetString(Calc_display , locstring);
	 	  XmTextFieldSetString(own_name , OWNfuncts[index].functionname);
		  free (locstring);
		  break;
		case 0:
		  index = getownfunction(name);
		  if(index < 0 ) break;
		  dobutton(
			OWNfuncts[index].functionname);
		  dobutton(
			"(");
		  break;
		case 2:		/* delete mode */
		  index = getownfunction(name);
		  if(index < 0 ) break;
		  free(	OWNfuncts[index].code);
		  OWNfuncts[index].code = NULL;
		  strcpy(OWNfuncts[index].functionname,"");  
		  display_allowncode();
	    	  break;

	  }
	XtFree(name);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	setconstant_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmListCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	checking if the selected list item in in the
 *			list of legal constants prints the value to input
 *
 *
 *  History:		Fri Jan  5 19:07:24 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void setconstant_cb (Widget parent, XtPointer data , XmListCallbackStruct * cbs ){

    char *item,string[60];
    int pos;
	pos = MListGetPosition(parent);
	if(pos <= 0 )return;
	item = MListGetString(parent);

	if(!strcmp(item,"PI"))
		sprintf(string,"%.8f",M_PI);
	else if(!strcmp(item,"E"))
		sprintf(string,"%.10f",M_E);
	else if(!strcmp(item,"RAN"))
		sprintf(string,"%d",rand());
	else
		return;
	dobutton(string);
	XtFree(item);
	XmListDeselectPos(parent,pos);
}
static void setdecimal_cb (Widget parent, XtPointer data , XmToggleButtonCallbackStruct * cbs ){

	if(!cbs->set)return;
	convertall(DECIMAL,Calc_display);
	convertall(DECIMAL,Calc_result);
	setdeztype();
	SetColorbyName(Calc_nummode,XmNbackground ,"green");
	makeposscomm();
}
static void sethex_cb (Widget parent, XtPointer data , XmToggleButtonCallbackStruct * cbs ){

	if(!cbs->set) return;
	convertall(HEX,Calc_display);
	convertall(HEX,Calc_result);
	sethextype();
	SetColorbyName(Calc_nummode,XmNbackground ,"cyan");
	makeposscomm();

}
static void setoctal_cb (Widget parent, XtPointer data , XmToggleButtonCallbackStruct * cbs ){

	if(!cbs->set) return;
	convertall(OCTAL,Calc_display);
	convertall(OCTAL,Calc_result);
	setocttype();
	SetColorbyName(Calc_nummode,XmNbackground ,"gold");
	makeposscomm();
}
static void setbinary_cb (Widget parent, XtPointer data , XmToggleButtonCallbackStruct * cbs ){

	if(!cbs->set)return;
	convertall(BINARY,Calc_display);
	convertall(BINARY,Calc_result);
	setbintype();
	SetColorbyName(Calc_nummode,XmNbackground ,"indianred");
	makeposscomm();
}
static void setimmediate_cb (Widget parent, XtPointer data , XmToggleButtonCallbackStruct * cbs ){

	if(!cbs->set )return;
	calcmode = 0;		/* 0 = immediate,(green) 1 = formula (gold)
				   2 = Programming (red) */
	SetColorbyName(Calc_mode,XmNbackground ,"green");
 	XtSetSensitive(Calc_paropen,FALSE);
 	XtSetSensitive(Calc_parclose,FALSE);
	XtSetSensitive(Calc_functions,FALSE);
	XtSetSensitive(Calc_ownfunctions,FALSE);
	XtSetSensitive(Calc_Xinput,FALSE);
	if(ownfunction) closeownfunction();
}
static void setformula_cb (Widget parent, XtPointer data , XmToggleButtonCallbackStruct * cbs ){

	if(!cbs->set)return;
	calcmode = 1;		/* 0 = immediate,(green) 1 = formula (gold)
				   2 = Programming (red) */
	SetColorbyName(Calc_mode,XmNbackground ,"gold");
 	XtSetSensitive(Calc_paropen,TRUE);
 	XtSetSensitive(Calc_parclose,TRUE);
	XtSetSensitive(Calc_functions,TRUE);
	XtSetSensitive(Calc_ownfunctions,TRUE);
	XtSetSensitive(Calc_Xinput,FALSE);
	if(ownfunction) closeownfunction();
	
}
static void setprogram_cb (Widget parent, XtPointer data , XmToggleButtonCallbackStruct * cbs ){

	if(!cbs->set) return;
	if(ownfunction) closeownfunction();
	SetColorbyName(Calc_mode,XmNbackground ,"indianred");
	ownfunction = own_Create(XtParent(parent));
 	XtSetSensitive(Calc_paropen,TRUE);
 	XtSetSensitive(Calc_parclose,TRUE);
	XtSetSensitive(Calc_functions,TRUE);
	XtSetSensitive(Calc_ownfunctions,TRUE);
	XtSetSensitive(Calc_Xinput,TRUE);
	calcmode = 2;
}
static void logpr_cb (Widget parent, XtPointer data , XmToggleButtonCallbackStruct * cbs ){

	if(cbs->set && !logger){
		Logprint_Create(XtParent(parent));
		logging = 1;
	}
	else if (!cbs->set && logger){
		MCloseDialog(logger);
		logger = 0;
	}
	logging = cbs->set;
}
static void errorbell_xb (Widget parent, XtPointer data , XmTextVerifyCallbackStruct * cbs ){

	 XBell(XtDisplay(parent), 100);
}
static void Errorquit_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	Error_error = 0;
	Error_E = 0;
	MCloseDialog(parent);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	test_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmPushButtonCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	Pressing the testbutton will use the value of Input
 *			field to evaluate the actual function and display the result
 *			in the owncode result field
 *
 *
 *  History:		Tue Jan 16 16:30:08 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void test_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

    char string[200],*inputval ,*check; 

	check  = XmTextFieldGetString(Calc_display);
	strcpy(string,check);
	XtFree(check); 
	strcat(string , "=");
 	check = string;
	if(!OWNcode)
	  {
		OWNcode = (OWNCODECALL *) malloc(sizeof(OWNCODECALL));
		memset(OWNcode,0,sizeof(OWNCODECALL));
	  }
	else
	  {
		OWNcode->next = (OWNCODECALL *) malloc(sizeof(OWNCODECALL));
		memset(OWNcode->next,0,sizeof(OWNCODECALL));
		OWNcode->next->back = OWNcode;
		OWNcode = OWNcode->next;
	  }
	inputval  = XmTextFieldGetString(own_input);
 	if(datatype == DECIMAL)
 	     {
 	   	 OWNcode->value = decodefloat(inputval) ;
 	   	 OWNcode->ivalue =  OWNcode->value;
 	   	 
 	    }
 	   else
 	    {
  	   	 OWNcode->ivalue = decodeint(inputval);
 	   	 OWNcode->value =  OWNcode->ivalue;
 	    }
    

	if(countparenth(string))
	   {
		OWNcode->STACKtop   	=STACKtop;
 		OWNcode->calcbottom 	=calcbottom;
 		OWNcode->calctop	=calctop; 
		OWNcode->string		= string;

		calcformula(&check,own_result);

		STACKtop = OWNcode->STACKtop;   	
 		calcbottom = OWNcode->calcbottom; 	
 		calctop = OWNcode->calctop;
		if(OWNcode->back)
		  {	
			OWNcode = OWNcode->back;
			free (OWNcode->next);
			OWNcode->next = NULL;
		  }
		else
		  {
			free (OWNcode);
			OWNcode = NULL;
		  }
	   }
	
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	saveowncode_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmPushButtonCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	takes actual function code from standard input field
 *			function name from name field. if same function is existing,
 *			it will be replaced. otherwise the first free entry in
 *			owncodes array will be used, or one added.
 *			code, name and datatype are stored. the acvtual functions will be 
 *			redisplayed and finally all funtions rewritten to file .
 *			all done after error checking.
 *			lateron a bak file will be created.
 *
 *
 *  History:		Tue Jan 16 17:03:56 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void saveowncode_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

   FILE *savefile;
   char *name, funcname[10]="",*function , errmsg[80],savepath[100];
   int i,OK=FALSE;
	


      if(programmode != 2)
	{			/* not deleting */
	name = XmTextFieldGetString(own_name);
	if(!name)
	  {
		calcerror("Function Name missing");
		return;
	  }
	for(i=0;i<4;i++)
		name[i] = toupper(name[i]);		/* only uppercase for name */
	function =  XmTextFieldGetString(Calc_display);
	if(!function)
	  {
		calcerror("No Function Code");
		return;
	  }
	if(!countparenth(function))
		return;
	if(*name != '%') strcpy(funcname,"%");
	strncat(funcname,name,4);
	funcname[4]=0;

	for (i=0; i < NownFunct ; i++)
	  if(!strcmp(OWNfuncts[i].functionname,funcname))
	    {			/* replacing */
		if(OWNfuncts[i].code)
			free(OWNfuncts[i].code);
		OWNfuncts[i].code = NULL;
		strcpy(OWNfuncts[i]. functionname,"");
		break;
	    }

	for (i=0; i < NownFunct ; i++)
	  if(!OWNfuncts[i].code)
	     {
		if(!allocateownfunc(i,function,funcname,datatype))
				return;
		OK = TRUE;
		break;
	     };
	if(!OK)
	   {
		if(++NownFunct >= MAXownFunct)
	 	 {
			calcerror("Cannot save, to many Owncode Functions");
			return;
	 	 }
		  
		allocateownfunc(NownFunct-1 ,function,funcname,datatype);
		
	   }
	}
	strcpy(savepath,getenv("HOME"));
	strcat(savepath,"/"OWNcodefile);
	if(!(savefile = fopen(savepath,"w")))
	   {
		sprintf(errmsg,"Cannot open %s for save owncode",OWNcodefile);
		calcerror(errmsg);
		return;
	   }
	for (i=0; i < NownFunct ; i++)
	  if(OWNfuncts[i].code)
	     {
		fprintf(savefile,"%s= %s (%d)\n",OWNfuncts[i].code
			,OWNfuncts[i].functionname,OWNfuncts[i].type);
	     };
	fclose(savefile);	
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	pgmquit_cb
 *  
 *  Input:		Widget parent, XtPointer data, XmPushButtonCallbackStruct *cbs
 *
 *  Return:		void
 *
 *  Documentation:	quit the program mode, returning to foremula
 *			no autosave is done
 *
 *
 *  History:		Sun Jan 21 10:35:15 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void pgmquit_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	calcmode = 1;		/* 0 = immediate,(green) 1 = formula (gold)
				   2 = Programming (red) */
	SetColorbyName(Calc_mode,XmNbackground ,"gold");
 	XtSetSensitive(Calc_paropen,TRUE);
 	XtSetSensitive(Calc_parclose,TRUE);
	XtSetSensitive(Calc_functions,TRUE);
	XtSetSensitive(Calc_ownfunctions,TRUE);
	XtSetSensitive(Calc_Xinput,FALSE);
  	XmToggleButtonSetState(Calc_form_mode,TRUE,TRUE);

	closeownfunction();
	
}
static void pgmsubpgm_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	programmode = 0;
	 SetColorbyName(  own_mode   ,XmNbackground ,"SteelBlue1");
 XUndefineCursor(XtDisplay(Calc_ownfunctions) ,XtWindow(Calc_ownfunctions) ); /*    wenn dieser Cursor nicht mehr verwendet wird: */

}
static void pgmsubedit_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	programmode = 1;
	SetColorbyName(  own_mode   ,XmNbackground ,"orange");
XDefineCursor(XtDisplay(Calc_ownfunctions) ,  XtWindow(Calc_ownfunctions) , editcursor);
}
static void pgmsubdel_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

XColor  fore , back , hardware;
	 SetColorbyName(  own_mode   ,XmNbackground ,"red");
	 XDefineCursor(XtDisplay(Calc_ownfunctions) ,  XtWindow(Calc_ownfunctions), delcursor);
if(!XLookupColor(XtDisplay(Calc_ownfunctions), DefaultColormap(XtDisplay(Calc_ownfunctions)
  ,DefaultScreen(XtDisplay(Calc_ownfunctions))), "red", &fore ,&hardware)) return; /* no color */
if(!XLookupColor(XtDisplay(Calc_ownfunctions), DefaultColormap(XtDisplay(Calc_ownfunctions)
 ,DefaultScreen(XtDisplay(Calc_ownfunctions))), "white", &back ,&hardware)) return; /* no color *
/*  now recolor cursor*/
XRecolorCursor(XtDisplay(Calc_ownfunctions) , delcursor,&fore,&back);

	programmode = 2;
}
static void logquit_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	 XmToggleButtonSetState(Calc_logger,FALSE,TRUE);
	
}
static void log_print_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

   char printer[100]="" , *log;
   FILE *pr;

	strcpy(printer,XmTextGetString(Logprint_printer));
	pr = popen(printer,"w");
	log = XmTextGetString(logger);
	fprintf(pr,"%s",log);
	pclose(pr);
	XFree(log);
	XmTextSetString(logger,"");
}
static void log_clear_cb (Widget parent, XtPointer data , XmPushButtonCallbackStruct * cbs ){

	 XmTextSetString (logger,"");
}

/*	FUNCTIONS */

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	allocateownfunc
 *  
 *  Input:		int index,char *function , char *funcname,int type
 *
 *  Return:		int
 *
 *  Documentation:	allocates space for code and copies the parameters
 *			to entry[index] of owncode array.
 *			redisplays all owncode
 *
 *  History:		Tue Jan 16 17:07:09 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static int allocateownfunc (int index,char *function , char *funcname,int type) {
	OWNfuncts[index].code = (char *)malloc(strlen(function)+2);
	if(!OWNfuncts[index].code)
	  {
		calcerror("Cannot allocate memory for saving");
		return FALSE;
	  }
	strcpy(OWNfuncts[index].code,function);
	strcpy(OWNfuncts[index].functionname,funcname);
	OWNfuncts[index].type = type;
	display_allowncode();
	return TRUE;
}

/***************************************************************************
 ***************************************************************************

  Functionname:		calcerror
  
  Input:		
  Output:   	    	
  
  Return:		 void 

  Documentation:	


  History:		Thu May 16 17:12:05 2002



 ***************************************************************************
 ***************************************************************************/
static void calcerror (char *message) {
	Error++;			/* flag the error */
	if(Error_E)
		  XmTextFieldSetString(Error_error , message);
	else
		 Error_E = Error_E_Create(XtParent(Calc_result),message);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	calcformula
 *  
 *  Input:		char **input,  Widget result
 *
 *  Return:		void
 *
 *  Documentation:	takes the pointer tp characterstring (normally from input textfield
 *			decodes it using reversepolish and calculates a result.
 *			result will be displayed in result field
 *
 *
 *  History:		Thu Jan  4 17:56:09 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void calcformula (char **input , Widget result) {
  REVP *item;
  char res[100]="";
  int i;
	    Error = 0;
	    while(  item = decodeitem(input))
	      {
	          if(! dorevp(item))
	            {
	              
	              item = calcrevp(calcbottom);
	              STACKtop =calcbottom =calctop = NULL;
	              break;
	             }
	      }
	if(Error)
	  {
	   while(calcbottom)
	    {
		item = calcbottom;
		calcbottom = item->next;
		free (item);
	    }
	   while(STACKtop)
	    {
		item = STACKtop;
		STACKtop = STACKtop->next;
		free (item);
	    }
	  STACKtop =calcbottom =calctop = NULL;
	  return;
	 }
	switch (datatype)
	  {
		case DECIMAL:
		
		printdec(res,item->value);
		break;
		case HEX:
		sprintf(res,"%lx",item->ivalue);
		break;		

		case OCTAL:
		sprintf(res,"%lo",item->ivalue);
		break;	

		case BINARY:
		for(i=0;i<32;i++,item->ivalue<<= 1)
		 {
		   if(item->ivalue & 0x80000000) strcat(res,"1");
		   else  strcat(res,"0");
		 }
	  }
	free(item);
	STACKtop =calcbottom =calctop = NULL;
	logit(res);
	XmTextFieldSetString(result , res);
	nactcomm = 0;	

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	calcint
 *  
 *  Input:		unsigned long int val1 , unsigned long int val2 , int code
 *
 *  Return:		int
 *
 *  Documentation:	calculates the result of an integer operation
 *			and displays it in input field and result field
 *
 *
 *
 *  History:		Fri Dec 29 17:06:02 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static u_long_int calcint(unsigned long int val1 , unsigned long int val2 , int code) {
  double ganz;

    if(!signmode)		/* signmode == 1  is signed int  == 0 unsigned */
      { 
	switch (code)
	 {
		case PLUS:
			return (val1 + val2);
		case MINUS:
			return (val1 - val2);
		case MAL:
			return (val1 * val2);
		case DIV:
			if(!val2) return( UINT_MAX);
			return (val1 / val2);
		case AND:
			return (val1 & val2);
		case OR:
			return (val1 | val2);
		case XOR:
			return (val1 ^ val2);
		case LSHIFT:
			return (val1 << val2);
		case RSHIFT:
			return (val1 >> val2);
		case EQUAL:
			return (val1);
		case POTENZ:
			if((!val1 && val2 <= 0) || (val1 < 0 && modf((double)val2,&ganz) != 0))
			   return (UINT_MAX);
			return (pow((double)val1,(double)val2));
		case SIGN:
			return (-val1);	
		case NOT:
			return (~val1);	
	  }
       }
     else
      {
	switch (code)
	 {
		case PLUS:
			return ((long int)val1 + (long int)val2);
		case MINUS:
			return ((long int)val1 - (long int)val2);
		case MAL:
			return ((long int)val1 * (long int)val2);
		case DIV:
			if(!val2) return( UINT_MAX);
			return ((long int)val1 / (long int)val2);
		case AND:
			return ((long int)val1 & (long int)val2);
		case OR:
			return ((long int)val1 | (long int)val2);
		case XOR:
			return ((long int)val1 ^ (long int)val2);
		case LSHIFT:
			return ((long int)val1 << (long int)val2);
		case RSHIFT:
			return ((long int)val1 >> (long int)val2);
		case EQUAL:
			return (val1);
		case POTENZ:
			if((!val1 && val2 <= 0) || (val1 < 0 && modf((double)val2,&ganz) != 0))
			   return (UINT_MAX);
			return (pow((double)val1,(double)val2));
		case SIGN:
			return (-val1);	
		case NOT:
			return (~val1);	
	  }
       }

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	calcowncode
 *  
 *  Input:		char **input ,REVP *result
 *
 *  Return:		void
 *
 *  Documentation:	nearly the same function as calcformula
 *			but returning the result in result->.value
 *			it is reentrant, as owncode may call another owncode
 *
 *
 *  History:		Sat Jan 20 08:45:35 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void calcowncode (char **input ,REVP *result) {
  REVP *item;
  int i;


	    Error = 0;
	    while(  item = decodeitem(input))
	      {
	          if(! dorevp(item) )
	            {
	              
	              item = calcrevp(calcbottom);
	              STACKtop =calcbottom =calctop = NULL;
	              break;
	             }
	      }
	if(Error)
	  {
	   while(calcbottom)
	    {
		item = calcbottom;
		calcbottom = item->next;
		free (item);
	    }
	   while(STACKtop)
	    {
		item = STACKtop;
		STACKtop = STACKtop->next;
		free (item);
	    }
	  STACKtop =calcbottom =calctop = NULL;
	  return;
	 }
	result->value = item->value;
	result->ivalue = item->ivalue;
	free (item);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	calcrevp
 *  
 *  Input:		REVP *bottom
 *
 *  Return:		REVP *
 *
 *  Documentation:	loops thru the queue starting with bottom, calculating the reverse polish
 *			following the Algorithm 6.3 from
 *			Seymour Lipschutz: Datenstrukturen
 *			returning the REVP structure with the final result. clearing out the original queue
 *			the global REVP *STACKtop is used for stack
 *
 *
 *
 *  History:		Thu Jan  4 17:23:46 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static REVP *calcrevp (REVP *bottom) {
      REVP *item ,*nextitem, *operandA , *operandB , dummy ;
      
      
      	item = bottom;
      	dummy.value = 0;
      	dummy.ivalue = 0;
      	
      	while (item->code != EQUAL)
      	   {
      	   	nextitem = item->next;
      	   	if(!item->code)	/* code  =  0 defines value (operand) */
      	   	 {
 
     	   	      pushrevp (item);
      	   	      item = nextitem;
      	   	  }
      	   	else 
      	   	  {
       	   	  	if(item->code >= SIGN)   /* beginning with SIGN are unary functions */
      	   	  	  {
/* at this point calculating reversepolish of own function (preconverted) may start with a different
   queue base */      	   	  	  
      	   	  	  	operandB  = STACKtop;
      	   	  	  	operandA = &dummy;
      	   	  	  }
      	   	  	else
      	   	  	  {
      	   	  		operandA = poprevp();
     	   	  	  	operandB = STACKtop;
      	   	  	  }
 			if(item->code == FUNC)
				dofunc(item , operandB);
			else
			{
      	   	  	  if(operandB->datatype == DECIMAL )
      	   	  	    	operandB->value = calculfloat(operandB->value
      	   	  	    		,operandA->value,item->code);  
  			  else
  				operandB->ivalue = (long int)calcint(operandB->ivalue
  					,operandA->ivalue,item->code);
			}
			if(operandB->datatype == DECIMAL)
			{
  			    if(operandB->value < LONG_MAX &&  operandB->value > LONG_MIN)
  				operandB->ivalue = operandB->value;
  			    else
  				operandB->ivalue = UINT_MAX;
			}
			else
			    operandB->value = operandB->ivalue;
  	/* no push needed, as we were working on STACKtop       pushrevp (operandB);   */
			if(item->code < SIGN)   
  				free(operandA);		/* free memory if not unary */
			free (item);	   /* free memory */
      	   	  }
      	     	item = nextitem;	  
  	  }
 	return poprevp();	/* last of stack should contain result */  						
/*   calling program should free the item after usage and reset STACKtop */

 
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	calculfloat
 *  
 *  Input:		double val1,double val2,int code
 *
 *  Return:		double
 *
 *  Documentation:	calculates the result of a floating operation
 *			and displays it in input field and result field
 *
 *
 *  History:		Fri Dec 29 17:05:09 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static double calculfloat (double val1,double val2,int code) {
  double ganz;

	switch (code)
	 {
		case PLUS:
			return (val1 + val2);
		case MINUS:
			return (val1 - val2);
		case MAL:
			return (val1 * val2);
		case DIV:
			if(!val2) return(MAXDOUBLE);
			return (val1 / val2);
		case EQUAL:
			return (val1);
		case POTENZ:
			if((!val1 && val2 <= 0) || (val1 < 0 && modf(val2,&ganz) != 0))
			   return (MAXDOUBLE);
			return (pow(val1,val2));
		case SIGN:
			return (-val1);	
	  }
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	closeownfunction
 *  
 *  Input:		void
 *
 *  Return:		void
 *
 *  Documentation:	resetting all to normal mode, normal cursor closing
 *			program dialog
 *
 *
 *  History:		Sun Jan 21 10:32:14 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void closeownfunction (void) {

	XFlush(XtDisplay(Calc_num_point));
	ownfunction = 0;
	programmode = 0;	/* set back to normal mode */
 XUndefineCursor(XtDisplay(Calc_ownfunctions) ,XtWindow(Calc_ownfunctions) ); /*    wenn dieser Cursor nicht mehr verwendet wird: */
	MCloseDialog(own_input);

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	convertall
 *  
 *  Input:		int mode
 *
 *  Return:		void
 *
 *  Documentation:	gets the total string of input display, breaks it depending on
 *			datatype ( p.e. HEX) converts the values into mode, redisplays them
 *			and displays all other commands (claiming problem if illegal
 *			commands for actual mode (not yet included)
 *
 *
 *  History:		Thu Dec 28 12:47:59 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void  convertall (int mode , Widget target) {
  char *input ,*oriin ,item[80]="";
  int i , savemode;
  double val;
  long int ival;

  /* get all input in   */
	oriin = input = XmTextFieldGetString(target);
	if(!input || !input[0]) return;		/* empty field */
	XmTextFieldSetString(target,"");   /* clear it first */
/* assume first character is value or sign (if not binary or octal) */	
	savemode = datatype;
     while(TRUE)
      {
	if(!*input)
		break;
	while(*input == '%')
	  {
	     strncpy(item,input,5);
	     input +=  5 ;
	     XmTextFieldInsert (target,XmTextGetLastPosition (target),item);
	   }
	item[0] = 0;	/* safety preclear */
	if(datatype ==  DECIMAL)
	  {
		val = decodefloat(input);
	  }
	else
	  {
		ival = decodeint(input);
	  }
	input++;		/* at least one digit or a sign so skip */
	if(mode == DECIMAL && datatype != DECIMAL)
	   {
		val = ival;
		printdec(item,val);
	   }
	else if(mode == DECIMAL)
		printdec(item,val);
	if(datatype == DECIMAL)
		ival = val;
	switch (mode)
	  {
		case HEX:
		sprintf(item,"%lx",ival);
		break;		

		case OCTAL:
		sprintf(item,"%lo",ival);
		break;	

		case BINARY:
		for(i=0;i<32;i++,ival<<= 1)
		 {
		   if(ival & 0x80000000) strcat(item,"1");
		   else  strcat(item,"0");
		 }
	  }
	datatype = mode;
	XmTextFieldInsert (target,XmTextGetLastPosition (target),item);
	if(!(input = strpbrk(input,posscommands)))  
			break;
	i=0;
	while(input[1] == input[0])
	   { 		/* assume double char command */
		item[i++] = *input++;
	   }
	while(*input == '%')
	  {
	     strncpy(item,input,5);
	     input +=  5 ;
	     XmTextFieldInsert (target,XmTextGetLastPosition (target),item);
	   }
	item[i++] = *input++;
	item[i] = 0;
	XmTextFieldInsert (target,XmTextGetLastPosition (target),item);
	datatype = savemode;
      }
	
	datatype = savemode;
	XtFree(oriin);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	countparenth
 *  
 *  Input:		char *string
 *
 *  Return:		int
 *
 *  Documentation:	counts parenthesis and checks for balance, if unbalenced, raises
 *			error display and returns fals.
 *
 *
 *  History:		Sat Jan  6 11:07:08 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static int countparenth (char *string) {
   char *next;
   int nopen=0,nclose=0 , delta;
	next= string;
	while(next = strchr(next,'('))
	 {
 		nopen++;
		next++;
	 }
	next= string;
	while(next = strchr(next,')'))
	  {
		next++;
		 nclose++;
	  }
	delta = nopen-nclose;
	if(!delta) return TRUE;
	calcerror("unbalanced parenthesis:");
	return FALSE;
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	decodefloat
 *  
 *  Input:		char *string
 *
 *  Return:		double
 *
 *  Documentation:	decodes the decimal values treated as double
 *
 *
 *  History:		Thu Dec 28 15:32:27 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
double decodefloat (char *string) {
  double val;

	sscanf(string,"%lf",&val);
	return val;	
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	decodeint
 *  
 *  Input:		char *string
 *
 *  Return:		unsigned long int
 *
 *  Documentation:	decodes all integer cases as HEX, OCTAL, BINARY
 *
 *
 *  History:		Thu Dec 28 13:12:45 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static u_long_int decodeint (char *string) {
  unsigned long int val = 0;
  
	while(isspace(*string)) string++;	/*skip all leading whitespace */
	switch(datatype)
	  {
		case HEX:
		sscanf(string,"%lx",&val);
		break;
		
		case OCTAL:
		sscanf(string,"%lo",&val);
		break;

		case BINARY:
		while(isdigit(*string) && *string < '2')
		  {
			val <<= 1;
			val += (*string - '0');
			string++;
		  }
		break;
	   }
	return val;
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	decodeitem
 *  
 *  Input:		char **string
 *
 *  Return:		REVP *
 *
 *  Documentation:	checking next item in *string being either a command or a value 
 *			(later a variable), creates a REVP item filling the values in.
 *			 string will be incremented to point behind the decoded item.
 *			 (leading blanks are skipped, interspersed blanks are 
 *			forbidden)
 *
 *
 *  History:		Thu Jan  4 17:33:02 1996
 *			Sat Jan 20 08:45:05 1996			added owncode
 *
 ***************************************************************************
 ***************************************************************************/
static REVP *decodeitem (char **string) {

 /*************     add FUNCTION as %XXX     (three chars + %)         prio  Potenz +1  code =POTENZ +1 */ 	
    int i , index ;
    REVP *item;
   static int prevcomm=0;	/* flag for sign check */ 
   char errmsg[5];
    
    	if(!strpbrk(*string,posscommands))
    	  {
    	  	prevcomm = 0;
    		return NULL;		/* the end of string must be a legal command */
	  }
    	item = (REVP *) malloc(sizeof(REVP));   /* allocate new item */
    	memset(item,0,sizeof(REVP));
    	while(isspace(**string )) *string += 1;   /* skip leading blanks */
    	  if(**string != 'X')
	    {
    	      for (i = 0 ; i <  npossexecs ; i++)     /* be careful, might be a sign */
    	        	if(**string == posscommands[i])
    	        	    {
    	        	    	if(!prevcomm && possexecs[i] == MINUS)  /* assume sign */
    	        	    	  {
    	        	    	  	item->code = SIGN;
    	        	    	  	item->priority = PSIGN;
    	        	    	  }	
    	        	    	else if((*string)[0] == (*string)[1] &&  possexecs[i] == MAL)
    	        	    	  {
    	        	    		item->code = POTENZ;
    	        	    		item->priority = PPOTENZ;
    	        	        		(*string) ++;    /* go beyond double char command */
     	        	    	  }
     	        	    	
    	        	    	 else
    	        	    	  {
   	        	        		item->code = possexecs[i];
    	        	        		item->priority = prio[i];
    	        	          }
     	        	        item->itemtype = 2;
    	        	        *string += 1;
				if(prevcomm && item->code == PAROPEN)
				   {
					calcerror("parenthesis after value");
					free (item);
					return NULL;
				    }
				if(!prevcomm && item->code != PAROPEN && item->code != SIGN)
				   {
					calcerror("two commands in sequence");
					free (item);
					return NULL;
				    }
    	        	        if(item->code == PARCLOSE )
    	        	        	 prevcomm = 1;
    	        	        else 
    	        	        	prevcomm = 0;
    	        	        return item;
    	        	     };
	       }
	    
    	    if(**string == '%')	/* must be a function */
    	       {
    	       	item->priority  = PFUNCTION;
    	       	item->code = FUNC;
    	       	strncpy(item->paraname,*string,4);
    	       	(*string+=4);
    	       	if(**string != '(')
		  {
    	       	    sprintf(errmsg,"ERROR: function %s not followed by parenthesis\n"
			,item->paraname);
		    calcerror(errmsg);
		    free (item);
    	       	    return NULL;
		  }
		 for(i=0; i<nfunctions;i++)
		   {				/* search for intrinsic function */
			if (!strncmp(item->paraname,funcs[i].funcname,4))
			  {  		/* got it */
			     if(funcs[i].functype == 1)
			       {
				   item->itemtype = 3;
			           item->func.dfunction = funcs[i].dfunction;
				}
			     else
				{
			      	   item->func.ifunction = funcs[i].ifunction;
				   item->itemtype = 4;
				}
			     break;
			   }
		   }
		if( !item->func.ifunction ) 
		  {
			if( (index = getownfunction(item->paraname)) < 0)
			  {		/* neither intrinsic nor owncode */
    	       	    	    sprintf(errmsg,"ERROR: function %s unknown\n"
			    ,item->paraname);
		   	    calcerror(errmsg);
		    	    free (item);
    	       	    	    return NULL;
			  }
			if(OWNfuncts[index].type == 1)
				item->itemtype = 5;
			else	
				item->itemtype = 6;
			
			item->func.ownfunc = &OWNfuncts[index];
		  }
		item->code=FUNC;
		item->priority = PFUNCTION;
    	        prevcomm = 0;
    	        return item;
   	       }
	     
	   else if(**string == 'X')
	     {
		if(OWNcode)
		   {
			item->value = OWNcode->value;
			item->ivalue = OWNcode->ivalue;
	           
		   }
		else
		  {
		    calcerror("ERROR: No calling Structure set, cannot set input value, bad Call\n");
		    free (item);
    	       	    return NULL;
		  }
	      }

 	   else if(datatype == DECIMAL)
 	     {
 	   	 if((item->value = decodefloat(*string)) < 0) (*string)++;
 	   	 item->ivalue =  item->value;
 	   	 
 	    }
 	   else
 	    {
  	   	 item->ivalue = decodeint(*string);
 	   	 item->value =  item->ivalue;
 	    }
 	   
	  *string = strpbrk(*string,posscommands);
	  item->datatype = datatype;
	  item->itemtype = 0;
	  item->priority  = 0;
	  prevcomm = 1;
	  return item;

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	display_allowncode
 *  
 *  Input:		void
 *
 *  Return:		void
 *
 *  Documentation:	displays all store owncode function names
 *
 *
 *  History:		Tue Jan 16 17:13:15 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void display_allowncode (void) {
  int i;
	MListDeleteAllItems(Calc_ownfunctions);
	for(i=0;i < NownFunct ; i++)
	   if(OWNfuncts[i].code)
		MListAddString(Calc_ownfunctions, OWNfuncts[i].functionname);;
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	dobutton
 *  
 *  Input:		char *insert
 *
 *  Return:		void
 *
 *  Documentation:	depending on isertmode (== 0 add) adds the given string to
 *			last posaition or actual insert position 
 *
 *
 *  History:		Sat Feb  3 17:06:54 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void dobutton (char *insert){

	if(!insertmode)		/* addmode */
		XmTextFieldInsert (Calc_display,XmTextGetLastPosition (Calc_display)
			,insert);
	else
		XmTextFieldInsert (Calc_display,XmTextFieldGetInsertionPosition(Calc_display)
			,insert);


}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	dofunc
 *  
 *  Input:		REVP *item ,REVP *operand
 *
 *  Return:		void
 *
 *  Documentation:	execute a function from item using operand
 *			the function type and address is stored in item
 *
 *
 *  History:		Fri Jan  5 19:05:16 1996
 *			Thu May 16 17:36:38 2002     added owncode calling
 *
 ***************************************************************************
 ***************************************************************************/
static void dofunc (REVP *item ,REVP *operand) {

	if(item->itemtype == 3)
	  {
		operand->value = item->func.dfunction(operand->value);
		operand->ivalue = operand->value;
	  }
	else if(item->itemtype == 4)
	  {
		operand->ivalue = item->func.ifunction(operand->ivalue);
		operand->value = operand->ivalue;
	  }
	  
	else if(item->itemtype > 4)	/* owncode function */
		doowncode(item,operand);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	doowncode
 *  
 *  Input:		REVP *item ,REVP *operand
 *
 *  Return:		void
 *
 *  Documentation:	saving actual stacks and queues in a special stack
 *			of owncode structure. the actual operand values are saved
 *			as well in this structure plus the actual calculating
 *			datatype. now the datatype is switched and the stored string
 *			of owncode function decoded and calcultated.
 *			the result is stored into operand, the original system
 *			stacks a, queues and datatype restored and the owncode stack
 *			freed by one item.
 *
 *
 *  History:		Sat Jan 20 08:49:16 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void doowncode (REVP *item ,REVP *operand) {
  char msg[60] , *ownstring;
  
			/* first get a stack entry for owncodes saving */
	if(!OWNcode)
	  {
		OWNcode = (OWNCODECALL *) malloc(sizeof(OWNCODECALL));
		memset(OWNcode,0,sizeof(OWNCODECALL));
	  }
	else
	  {
		OWNcode->next = (OWNCODECALL *) malloc(sizeof(OWNCODECALL));
		memset(OWNcode->next,0,sizeof(OWNCODECALL));
		OWNcode->next->back = OWNcode;
		OWNcode = OWNcode->next;
	  }
	OWNcode->ivalue = operand->ivalue;	/* inputs */
	OWNcode->value = operand->value;
	if(!countparenth(item->func.ownfunc->code))
	   {
		sprintf(msg,"ERROR In owncode function %s ",item->func.ownfunc-> functionname);
		calcerror(msg);
		return;
	   }
		OWNcode->STACKtop   	=STACKtop;
 		OWNcode->calcbottom 	=calcbottom;
 		OWNcode->calctop	=calctop; 
		OWNcode->string		= item->func.ownfunc->code;
		ownstring = OWNcode->string ;
		OWNcode->datatype 	= datatype ;
		datatype = item->func.ownfunc->type;
		calcbottom = calctop = STACKtop = NULL;     /* we need to start another queue  */
		calcowncode(&ownstring,operand);
		STACKtop = OWNcode->STACKtop;   	
 		calcbottom = OWNcode->calcbottom; 	
 		calctop = OWNcode->calctop;
		datatype = OWNcode->datatype;
		if(OWNcode->back)
		  {	
			OWNcode = OWNcode->back;
			free (OWNcode->next);
			OWNcode->next = NULL;
		  }
		else
		  {
			free (OWNcode);
			OWNcode = NULL;
		  }
	

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	dorevp
 *  
 *  Input:		REVP *item
 *
 *  Return:		int
 *
 *  Documentation:	takes item and does reverse polish following the Algorithm 6.4 from
 *			Seymour Lipschutz: Datenstrukturen
 *			returning TRUE if not done, FALSE if all finished (i.e. code == EQUAL
 *			the global REVP *STACKtop is used for stack
 *
 *
 *  History:		Thu Jan  4 17:25:29 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static int dorevp (REVP *item) {
     REVP *actitem;

  	if(!item->code )		/* value ore operand */
  	  {
  		tocalc(item);	/* pass it to calcqueue */
  		return TRUE;
  	  }
	if(item->code == EQUAL)	/* last so empty stack */
	  {
	       while(tocalc(poprevp()));
	       tocalc(item);		/* add equal as last calccommand */
	       return FALSE;
	  }
	if(item->code == PAROPEN)   /*  openparenenthesis push it */
		 pushrevp(item);       
	else if(item->code == PARCLOSE)   /* close parenthsis, pop until open one */
	  {

		free(item);   	/* close parenthesis no longer needed */
	  	while((actitem = poprevp()) && actitem->code != PAROPEN)
	  	  	tocalc(actitem);
			free(actitem);  	/*open parenthesis no longer needed */

	  }
	else
	  {
	  	while(STACKtop && (STACKtop->code != PAROPEN) 
	  		&& (STACKtop->priority >= item->priority))
	  	      tocalc(poprevp());
	  	 pushrevp(item);
	 }
   	return TRUE;

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	execute_immediate
 *  
 *  Input:		void
 *
 *  Return:		void
 *
 *  Documentation:	Assuming two values separated by a legal command
 *			and terminated by a legal command calculates the
 *			result
 *
 *
 *  History:		Fri Dec 29 16:16:10 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static char *execute_immediate (char *string) {
  double val1,val2,result;
  unsigned long int ival1,ival2,iresult;
  int i,dou=0 ,code;
  char res[100]="",actcom[2]=" ";
  char *oristring  = string,*checkstring;

	if(datatype ==  DECIMAL)
	  {
		val1 = decodefloat(string);
		if(*string == '-') string++;	/* skip sign */
	  }
	else
	  {
		if(*string == '~')
		  {
			string++;
			ival1 = ~decodeint(string);
		  }
		else
			ival1 = decodeint(string);
	  }
	if(!(string = strpbrk(string,posscommands))) 
	  {
		return (oristring);
	  }
	for(i=0; i< npossexecs;i++)
		if(*string == posscommands[i])
		  {
			code = possexecs[i];
			break;
		  };
	while(string[1] == string[0])
	  {
		if(string[0] == '*')    code = POTENZ;	
		dou++;
		string++;
	  }
	string++;
	while(isspace(*string )) string++;  /* skip blanks */

	if(strchr(posscommands,*string) && *string != '-' && *string != '~')
	  {
		calcerror("two commands in serquence");
		return NULL;
	  }
	if(datatype ==  DECIMAL)
	  {
		val2 = decodefloat(string);
		if(*string == '-') string++;	/* skip sign */
	  }
	else
	  {
		if(*string == '~')
		  {
			string++;
			ival2 = ~decodeint(string);
		  }
		else
			ival2 = decodeint(string);

	  }
	
		
	switch (datatype)
	  {
		case DECIMAL:
		result = calculfloat(val1,val2,code);
		printdec(res,result);
		break;
		case HEX:
		iresult =  calcint(ival1 , ival2 , code);
		sprintf(res,"%lx",iresult);
		break;		

		case OCTAL:
		iresult =  calcint(ival1 , ival2 , code);
		sprintf(res,"%lo",iresult);
		break;	

		case BINARY:
		iresult =  calcint(ival1 , ival2 , code);
		for(i=0;i<32;i++,iresult<<= 1)
		 {
		   if(iresult & 0x80000000) strcat(res,"1");
		   else  strcat(res,"0");
		 }
	  }
	if((string = strpbrk(string,posscommands))) 
	  {
 		if(*string == '=')
		  {
		     logit(res);
		     string = NULL;
	  	     XmTextFieldSetString(Calc_display , "");  /* no continuation just clear*/
		  }
		else{
		     logit(res);
 	  	     XmTextFieldSetString(Calc_display , res);  /* put result for next calc */
		}
	  }
	if(code == EQUAL)
	   {
		logit(res);
		string = NULL;
	  	XmTextFieldSetString(Calc_display , "");  /* no continuation just clear*/
	   }

 	XmTextFieldSetString(Calc_result , res);
	nactcomm = 0;	
	XtSetSensitive(Calc_numdez,TRUE);
	return (string);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	getcalc
 *  
 *  Input:		void
 *
 *  Return:		REVP *
 *
 *  Documentation:	from bottom to top gets the next item of calc queue
 *			updating the queue. return NULL if empty
 *
 *
 *  History:		Thu Jan  4 17:20:44 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
REVP *getcalc (void) {
     REVP *item = calcbottom;
      
      	if(!item) 
      		return item;
      	calcbottom = calcbottom->next;
      	item->next = item->back = NULL;
      	if(calcbottom)calcbottom->back = NULL;
      	return item;

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	getownfunction
 *  
 *  Input:		char *name
 *
 *  Return:		int
 *
 *  Documentation:	looks for a valid entry with given name and returns the index
 *
 *
 *  History:		Wed Jan 17 17:09:33 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static int getownfunction (char *name) {
  int i;
	for(i=0; i< NownFunct ; i++)
	  {
		if( OWNfuncts[i].code)
		  {
		     if(!strncasecmp(name, OWNfuncts[i].functionname,4))
				return i;
		  }
		  
	  }
	return (-1);
}
static void logit (char *res) {
  char *stringo ,string[400] ;

	if(!logger || !logging)
		return;
	stringo = XmTextFieldGetString(Calc_display);
	strcpy(string,stringo);
	if(res){
		strcat(string,"=");
		strcat(string,res);
	}
	strcat(string,"\n");
	XmTextInsert(logger,XmTextGetLastPosition(logger) , string);
	XFree(stringo);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	lsbfirst
 *  
 *  Input:		long unsigned int hex
 *
 *  Return:		long unsigned int
 *
 *  Documentation:	reversts the given 32 bits of input into lsb first notation
 *
 *
 *  History:		Sat Feb  3 16:34:28 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static long lsbfirst (long  int hexin) {
  long unsigned int hex = (long unsigned int)hexin;
  long  int  result = 0;
  int i;


	for (i=0 ; i< 32 ; i++)
	  {
		result <<= 1;
		if(hex & 1 )
			result |= 1;
		hex >>= 1;
	  }
	return result;
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	makeposscomm
 *  
 *  Input:		void
 *
 *  Return:		void
 *
 *  Documentation:	stores the possible commands and their exec codes
 *			to global base. (depends on actual mode)
 *
 *
 *  History:		Fri Dec 29 16:11:26 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void makeposscomm (void) {


	strcpy(posscommands,commands);
	memcpy(possexecs, execs, sizeof(short int)*ncommands);
	memcpy(possprios, prio,sizeof(short int)*ncommands);
	npossexecs = ncommands;
	if(datatype != DECIMAL)
	  {
		strcat(posscommands,hexcommands);
		memcpy(&possexecs[ncommands], hexexecs, sizeof(short int)*nhexcommands);
		memcpy(&possprios[ncommands], hexprio, sizeof(short int)*nhexcommands);
		npossexecs += nhexcommands;
	  }
	strcat(posscommands,"()=");
	possprios[npossexecs] = PPAROPEN;
	possexecs[npossexecs++] = PAROPEN;
	possprios[npossexecs] = PPARCLOSE;
	possexecs[npossexecs++] = PARCLOSE;
	possprios[npossexecs] = PEQUAL;
	possexecs[npossexecs++] = EQUAL;
	

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	maycommand
 *  
 *  Input:		char *input, int nchars
 *
 *  Return:		int
 *
 *  Documentation:	checks if the given characters begin with a legal 
 *			command as + - etc. if it is, prepare for it
  *			if immediate mode and second command execute
 *
 *
 *  History:		Wed Dec 27 16:45:32 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
int maycommand (char *input, int nchars) {
  int i;
  char *check;
	if(!calcmode && (*input == '(' || *input == ')'))  /* immediate mode, no prarenthis */
		 return FALSE;
	if(calcmode && *input == '%')
		return TRUE;				/* may be function */
	if(check = strchr(posscommands, (int )*input))
	  {
			/* after any hex command no decimal poss */
/******		if(strchr(hexcommands,(int )*input))  
				XtSetSensitive(Calc_numdez,FALSE);
*****/
		return TRUE;
	  }
	return FALSE;
}
static double myacos (double val) {
	if(!trigmode)
		return ((180/M_PI)*acos(val));
	else
		return(acos(val));

}
static double myasin (double val) {
	if(!trigmode)
		return ((180/M_PI)*asin(val));
	else
		return(asin(val));

}
static double myatan (double val) {
	if(!trigmode)
		return ((180/M_PI)*atan(val));
	else
		return(atan(val));

}
static double mycos (double val) {
	if(!trigmode)
		val = (M_PI *val)/180.0;
	return (cos(val));

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	myln
 *  
 *  Input:		double val
 *
 *  Return:		double
 *
 *  Documentation:	adatpter to log ( natural logarithm) with error check
 *
 *
 *  History:		Sat Feb  3 16:33:18 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static double myln (double val) {

	if(val <= .0)  return 0.0;
	return log(val);

}
static double mylog (double val) {

	if(val <= .0)  return 0.0;
	return log10(val);
}
static long myrand (long int val) {

	return (rand());
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	mysin
 *  
 *  Input:		double val
 *
 *  Return:		double
 *
 *  Documentation:	my local sin function (converting deg to radians)
 *
 *
 *  History:		Fri Jan  5 16:49:28 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static double mysin (double val) {

	if(!trigmode)
		val = (M_PI *val)/180.0;
	return (sin(val));
}
static double mytan (double val) {
	if(!trigmode)
		val = (M_PI *val)/180.0;
	return (tan(val));


}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	poprevp
 *  
 *  Input:		void
 *
 *  Return:		REVP *
 *
 *  Documentation:	returns the item from top of stack,  deleting it from top
 
 *
 *
 *  History:		Thu Jan  4 17:30:13 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static REVP *poprevp (void) {
      REVP *item  = STACKtop;
       
       	if(!item) return NULL;
        	STACKtop = item->next;
       	if(item->next)
       		STACKtop->back = NULL;
       	item->next = item->back  = NULL;
       	return item;

}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	printdec
 *  
 *  Input:		char *item,double val
 *
 *  Return:		void
 *
 *  Documentation:	sprintf for floating values, eliminating trailing zeros
 *
 *
 *  History:		Sun Dec 31 09:52:33 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/
static void printdec (char *item,double val) {
  int i;
  char loc[80];


	sprintf(loc,"%g",val);
	if(strchr(loc,'e'))
	  {
		if(strstr(loc,"e-"))
		    sprintf(item,"%10.10f",val);
		else
		    sprintf(item,"%.0f",val);
	  }
	else
		sprintf(item,"%f",val);
	if(strchr(item,'.'))
	   for (i=strlen(item)-1;item[i] == '0';i--)
		 item[i]=0;
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	pushrevp
 *  
 *  Input:		REVP *item
 *
 *  Return:		int
 *
 *  Documentation:	links item on top of stack

 *
 *
 *  History:		Thu Jan  4 17:29:16 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static int pushrevp (REVP *item) {
  	item->next = STACKtop;
  	if(STACKtop) STACKtop->back = item;
 	STACKtop = item;
  	item->back = NULL;
    	return TRUE;

}

/***************************************************************************
 ***************************************************************************

  Functionname:		setbintype
  
  Input:		
  Output:   	    	
  
  Return:		 void 

  Documentation:	


  History:		Thu May 16 18:24:10 2002



 ***************************************************************************
 ***************************************************************************/
static void setbintype (void) {

	XtSetSensitive(Calc_num_hex,FALSE);
	XtSetSensitive(Calc_num_9,FALSE);
	XtSetSensitive(Calc_num_8,FALSE);
	XtSetSensitive(Calc_num_7,FALSE);
	XtSetSensitive(Calc_num_6,FALSE);
	XtSetSensitive(Calc_num_5,FALSE);
	XtSetSensitive(Calc_num_4,FALSE);
	XtSetSensitive(Calc_num_3,FALSE);
	XtSetSensitive(Calc_num_2,FALSE);
	XtSetSensitive(Calc_num_point,FALSE);
	datatype = BINARY;
	XtSetSensitive(Calc_hexop,TRUE);
}
static void setdeztype (void) {

	XtSetSensitive(Calc_num_hex,FALSE);
	XtSetSensitive(Calc_num_9,TRUE);
	XtSetSensitive(Calc_num_8,TRUE);
	XtSetSensitive(Calc_num_7,TRUE);
	XtSetSensitive(Calc_num_6,TRUE);
	XtSetSensitive(Calc_num_5,TRUE);
	XtSetSensitive(Calc_num_4,TRUE);
	XtSetSensitive(Calc_num_3,TRUE);
	XtSetSensitive(Calc_num_2,TRUE);
	XtSetSensitive(Calc_num_point,TRUE);
	datatype = DECIMAL;
	XtSetSensitive(Calc_hexop,FALSE);
}static void sethextype (void) {

	XtSetSensitive(Calc_num_hex,TRUE);
	XtSetSensitive(Calc_num_9,TRUE);
	XtSetSensitive(Calc_num_8,TRUE);
	XtSetSensitive(Calc_num_7,TRUE);
	XtSetSensitive(Calc_num_6,TRUE);
	XtSetSensitive(Calc_num_5,TRUE);
	XtSetSensitive(Calc_num_4,TRUE);
	XtSetSensitive(Calc_num_3,TRUE);
	XtSetSensitive(Calc_num_2,TRUE);
	XtSetSensitive(Calc_num_point,FALSE);
	datatype = HEX;
	XtSetSensitive(Calc_hexop,TRUE);
}
static void setocttype (void) {

	XtSetSensitive(Calc_num_hex,FALSE);
	XtSetSensitive(Calc_num_9,FALSE);
	XtSetSensitive(Calc_num_8,FALSE);
	XtSetSensitive(Calc_num_7,TRUE);
	XtSetSensitive(Calc_num_6,TRUE);
	XtSetSensitive(Calc_num_5,TRUE);
	XtSetSensitive(Calc_num_4,TRUE);
	XtSetSensitive(Calc_num_3,TRUE);
	XtSetSensitive(Calc_num_2,TRUE);
	XtSetSensitive(Calc_num_point,FALSE);
	datatype = OCTAL;
	XtSetSensitive(Calc_hexop,TRUE);
}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	tocalc
 *  
 *  Input:		REVP *item
 *
 *  Return:		int
 *
 *  Documentation:	adds item to top of calc queue, returns FALS if no item 
 *
 *
 *  History:		Thu Jan  4 17:22:18 1996
 *
 *
 ***************************************************************************
 ***************************************************************************/
static int tocalc (REVP *item) {
	if(!item) return FALSE;
	if(!calcbottom)  
	  {
	  	calcbottom = calctop = item;
	  	return TRUE;
	  }
	calctop->next  = item;
	item->back = calctop;
	calctop = item;
	return TRUE;
}
