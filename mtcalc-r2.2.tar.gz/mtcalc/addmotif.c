/*  $Header: /cvsroot/m-d-calculator/m-d-calculator/addmotif.c,v 2.2 2002/06/15 09:31:57 keidel Exp $ */
/*
 * $Log: addmotif.c,v $
 * Revision 2.2  2002/06/15 09:31:57  keidel
 * changed to be based on EasyMotif
 *
 * Revision 2.1  2001/11/01 09:31:56  keidel
 * set revision 2  as beta version
 *
 * Revision 1.3  2001/10/30 17:03:23  keidel
 * added help using browser via resource-file and environment EasyMotif
 * extended Clipboard to save/restore  from file
 * no help on filebox if using libeasmofif.a
 * Makefile for SGI
 *
 * Revision 1.2  2001/09/01 07:14:08  keidel
 * added scaler (slider)-widget
 * added conditionals     use  -DLINUX   or -DSGI in Makefile
 *
 * Revision 1.7  2000/09/05 08:41:55  keidel
 * create filtere fbox   dont return if plaoin directory
 *
 * Revision 1.6  2000/04/05 04:54:59  keidel
 * .linux adaptions
 *
 * Revision 1.5  1998/02/06 06:35:13  keidel
 * adaptions to option -fullwarn IRIX 6.4
 *
 * Revision 1.3  1997/09/03  12:04:40  keidel
 * changed display of hex-numbers from %x  to %X 
 *
 * Revision 1.2  1996/12/04  12:32:40  keidel
 * corrected null char string check in gethex
 *
 * Revision 1.1  1996/10/08  11:50:33  keidel
 * Initial revision
 *
 */
/* INCLUDES */
#include <Xm/XmAll.h>
#include <XMind.h>
#include <Xm/FileSB.h>

#include <sys/stat.h>
#include <unistd.h>
#include <ctype.h>
#include 	"Motifdialog.h"

static  void  ActionCallback(Widget parent, void (*function)(char *), XmFileSelectionBoxCallbackStruct *cbs);

void GrabDelete(Widget dialog , XtCallbackProc call ) 
{
   Atom WM_DELETE_WINDOW;

	XtVaSetValues(dialog , XmNdeleteResponse,XmDO_NOTHING , NULL);
	WM_DELETE_WINDOW = XmInternAtom(XtDisplay(dialog)
		, "WM_DELETE_WINDOW" , False);
	XmAddWMProtocolCallback(dialog,WM_DELETE_WINDOW , call
		, (XtPointer)dialog);

}


/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	CreatefilteredFileBox
 *  
 *  Input:		Widget parent, char *path, 
 *                      (XtCallbackProc)ActionCallback , char * selected
 *
 *  Return:		Widget FileBox
 *
 *  Documentation:	Creates a FileSelectionDialog and adds two callbacks.
 *			the user callback "ActionCallback" with data char *
 *			it should retrieve the selected item. It is linked to
 *			the OK button	
 *

 *
 *  History:		22.1.95
 *  changed 	Wed Oct 25 08:27:36 MDT 1995
 *
 *
 ***************************************************************************
 ***************************************************************************/

static  void  ActionCallback(Widget parent, void (*function)(char *), XmFileSelectionBoxCallbackStruct *cbs)
{
  String fileString;

  
  
/*  XmStringGetLtoR(cbs->dir, XmSTRING_DEFAULT_CHARSET, &dirString); */
  XmStringGetLtoR(cbs->value, XmSTRING_DEFAULT_CHARSET, &fileString);
  if(fileString[strlen(fileString)-1] == '/')
      return;
  XtDestroyWidget(parent);
  function (fileString);
}

Widget CreatefilteredFBox (Widget parent, char *path ,void (*function)(char *)
		, char *title)
  {
  Widget FileBox;
  Arg args[40];
  Cardinal n;
  XmString tmpLabelString = NULL;

 	FileBox = XmCreateFileSelectionDialog(XtParent(parent), title, NULL, 0);

	n=0;
/*	set the search path */

  	tmpLabelString = XmStringCreate(path, XmSTRING_DEFAULT_CHARSET);  
 	XtSetArg(args[n], XmNdirMask, tmpLabelString); n++ ;  /* thats OK */

 	XtSetValues(FileBox,args,n) ; 


  	XtManageChild(FileBox);
	XtUnmanageChild(XtNameToWidget(FileBox,"Help"));
  /* It's tricky: XtDestroyWidget is a Motif function. In this case,   */
  /* XtDestroyWidget destroys the FileBox-Widget, that's what we want. */

  	XtAddCallback(FileBox, XmNcancelCallback, (XtCallbackProc)XtDestroyWidget, NULL);

  /* Double-click or activate 'OK'-Button: Jump to ActionCallback,     */
  /* User defined               */

  	XtAddCallback(FileBox, XmNokCallback,(XtCallbackProc) ActionCallback
		, (XtPointer)function);
 	XmStringFree(tmpLabelString);
	return FileBox;
}  
  

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	GetColorbyName
 *  
 *  Input:		Widget w , char *colorstr
 *
 *  Return:		unsigned long 
 *
 *  Documentation:	gets the pixel value for the given colout name
 *			"colorstr"   may be used to set background
 *
 *
 *  History:		29.10.94
 *
 *
 ***************************************************************************
 ***************************************************************************/
unsigned long GetColorbyName(Widget w , char *colorstr) 
{
  int screen , stat;
  Display *dis;
  XColor hardware , RGB;

	dis = XtDisplay(w);
	screen = DefaultScreen(dis);
	stat = XLookupColor(dis , DefaultColormap(dis,screen),
		colorstr, &RGB,&hardware);
	if(stat) XAllocColor(dis,DefaultColormap(dis,screen),&hardware);
	return (hardware.pixel);


}

/***************************************************************************
 *
 *  Funktionsname:	MTxtGetHex
 *  
 *  Input:		Widget parent (Widget class XmText)
 *
 *  Return:		Integer value, zero when failed.
 *
 *  Documentation:	MTextGetInt is a function to access the contents
 *			of text-widgets. MTextGetInt converts the string     
 *			into an integer.
 *
 *
 *
 *  History:		27.12.94	generated by WizAnt  J.keidel
 *
 *
 ***************************************************************************/
 

int MTxtGetHex(Widget parent)
{
  char *contents;			/* Text-widget contentes	*/
  long int value;

  if((contents = XmTextGetString(parent))) { 
    if (contents[0] == 0) 		/* Invalid String ?		*/
      value = 0;
    else
      sscanf(contents,"%x",(long int *)&value);
  } else {
      value = 0;
  }

  XtFree(contents);			/* Free string			*/
  return value;				/* Return integer value		*/
} 


/***************************************************************************
 *
 *  Funktionsname:	MTxtSetHex
 *  
 *  Input:		Widget parent, int value
 *
 *  Return:		Bool
 *
 *  Documentation:	Sets an integer value into text-widgets as hex number. 
 *			Returns	TRUE when success, otherwise FALSE.
 *
 *  History:		27.12.94	created by WizAnt  J.keidel
 *
 *
 ***************************************************************************/
 
Bool MTxtSetHex(Widget parent, int value)
{

  char str[50];

  sprintf(str,"%8.8X",value);


  if (str && str[0]) {
    XmTextSetString(parent, str);
  }
  return (str!=NULL);
}
	

/***************************************************************************
 *
 *  Funktionsname:	MTextGetHexlong
 *  
 *  Input:		Widget parent (Widget class XmText)
 *
 *  Return:		long long Integer value, zero when failed.
 *
 *  Documentation:	MTextGetInt is a function to access the contents
 *			of text-widgets. MTextGetInt converts the string     
 *			into an integer.
 *
 *
 *
 *  History:		21.6.95	generated by WizAnt  J.keidel
 *
 *
 ***************************************************************************/
 

long long  MTextGetHexlong(Widget parent)
{
  char *contents;			/* Text-widget contentes	*/
  long long value;

  if((contents = XmTextGetString(parent))) { 
    if (contents[0] == 0) 		/* Invalid String ?		*/
      value = 0;
    else
      sscanf(contents,"%llx",&value);
  } else {
      value = 0;
  }

  XtFree(contents);			/* Free string			*/
  return value;				/* Return integer value		*/
} 


/***************************************************************************
 *
 *  Funktionsname:	MTextSetHexlong
 *  
 *  Input:		Widget parent, int value
 *
 *  Return:		Bool
 *
 *  Documentation:	Sets an integer value into text-widgets as hex number. 
 *			Returns	TRUE when success, otherwise FALSE.
 *
 *  History:		21.6.95	created by WizAnt  J.keidel
 *
 *
 ***************************************************************************/
 
Bool MTextSetHexlong(Widget parent, long long value)
{

  char str[50];

  sprintf(str,"%16.16llX",value);


  if (str && str[0]) {
    XmTextSetString(parent, str);
  }
  return (str!=NULL);
}
	

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	SetColorbyName
 *  
 *  Input:		Widget target , String XmNforeground , char * colorname
 *
 *  Return:		
 *
 *  Documentation:	changes the color of target widget either foregound
 *			or background
 *
 *
 *  History:		Started 31.10.94
 *
 *
 ***************************************************************************
 ***************************************************************************/
void SetColorbyName(Widget target,String ground ,char *color) 
{
  int Narg;
  Arg	args[20];

	Narg=0;
	XtSetArg(args[Narg],ground,GetColorbyName(target,color));
	Narg++;
	XtSetValues(target,args,Narg);


}

/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	get16hex
 *  
 *  Input:		char *string , 
 *
 *  Return:		long unsigned int *value
 *
 *  Documentation:	void function get16flz gets a long hexadecimal value
 *		     (64 bit) from string
 *
 *
 *  History:		28.12.94
 *
 *
 ***************************************************************************
 ***************************************************************************/
void get16hex(char *string , long unsigned int *value) 
{
   register char term='\0';

   register int i = 0;
   *value = *(value+1) = 0;        /* preclear */

   while ((term = *string++) != '\0' &&
           term != ' ')              
  {
     term=tolower(term);          /*  convert to lower case it's easier */
     if(isdigit(term) && !i)      /* convert numeric digit  */
     {
        *value = (*(value+1) >> 28) | *value <<4 ;
        *(value+1) = (*(value+1) << 4 ) | (int)(term-'0');
     }
     else if (term >='a' && term <='f' && !i)
     {
/*
       convert alpha digit  "a to f "
*/
        *value = (*(value+1) >> 28) | *value <<4 ;
        *(value+1) = (*(value+1) << 4 ) | (int)(term-'W');
     }
     else if( *(value+1) != 0)
        i++;
/*
   terminate conversion at non hex
*/
 }
 if (term == '\n' || term == '!') term = '\0';


}
  
#include <Xm/XmAll.h>
/*   $Revision: 2.2 $    */
/*
$Log: addmotif.c,v $
Revision 2.2  2002/06/15 09:31:57  keidel
changed to be based on EasyMotif

Revision 2.1  2001/11/01 09:31:56  keidel
set revision 2  as beta version

Revision 1.3  2001/10/30 17:03:23  keidel
added help using browser via resource-file and environment EasyMotif
extended Clipboard to save/restore  from file
no help on filebox if using libeasmofif.a
Makefile for SGI

Revision 1.2  2001/09/01 07:14:08  keidel
added scaler (slider)-widget
added conditionals     use  -DLINUX   or -DSGI in Makefile

Revision 1.9  1998/02/06 06:37:09  keidel
adaptions to option -fullwarn IRIX 6.4

 * Revision 1.8  1997/09/24  10:30:38  keidel
 * added backgroundcolor from parent, if actual is highlight
 *
 * Revision 1.7  1997/09/24  10:23:18  keidel
 * internal correction
 *
*/
/***************************************************************************
 ***************************************************************************
 *
 *  Functionname:	nav_highlight
 *
 *
 *  Prototype:	void nav_highlight(Widget w);
 *  
 *  Input:		Widget w    + Resource "highlight"
 *
 *  Output:		
 *
 *  Return:		
 *
 *  Documentation:	at enter cursor changes the background colour to
 *			the colour, given by resource .
 *			 At leving the widget, restores the original
 *			colours.
 *	Resource example:	Test*Highlight : cyan

 *
 *  History:		Mon Apr 28 07:20:15 MDT 1997
 *
 *
 ***************************************************************************
 ***************************************************************************/

static void Highlight_on_cursor ( Widget w , void *data , XEvent *event);

void nav_highlight(Widget w){

	XtAddEventHandler(w , EnterWindowMask | LeaveWindowMask
	    ,FALSE,(XtEventHandler) Highlight_on_cursor, NULL);
}


static void Highlight_on_cursor ( Widget w , void *data , XEvent *event){
  static Pixel bg,high = -1;
  XtResource request;
  
  	if(high == -1){
  		request.resource_name = "highlight";
  		request.resource_class= "Highlight";
  		request.resource_type = XtRPixel;
  		request.resource_size = sizeof(Pixel);
  		request.resource_offset = 0;
  		request.default_addr  = (XtPointer)NULL;
		request.default_type	=XmRImmediate;
  		XtGetSubresources(w, (XtPointer)&high,"highlight"
  		   , "Highlight", &request,1,NULL,0);
  	}
  	if(event->type == EnterNotify){
  			/* get original values for save */
  		XtVaGetValues(w , XmNbackground , &bg,NULL);
  		if(bg == high)
  			XtVaGetValues(XtParent(w), XmNbackground , &bg,NULL);
  		XtVaSetValues(w , XmNbackground , high,NULL);  
	}
	else if(event->type == LeaveNotify)
		XtVaSetValues(w , XmNbackground , bg,NULL);
}		 
