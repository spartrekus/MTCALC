/* TYPEDEFS */

#ifndef _XMINDWIDGETS_INCLUDED
#define _XMINDWIDGETS_INCLUDED

#include <Xm/XmHTML.h>

#ifdef ANSI
#define P(x) x
#else
#define P(x) ()
#endif

/* HTML FUNCTIONS */

int    MGetMimeType(char *file);
char * MGetMimeTypeString(char *file);
char *  MHtmlLoadFile(char *filename, int *errno);
char *  MGetPath(char *FileName);
Bool    MHtmlSetFile(char *filename, Widget wid);
void    MHtmlActivateCallback(Widget parent, XtPointer data, XmHTMLAnchorCallbackStruct *cbs);
int 	MHtmlSetHistory(Widget wid, char *file, char *loc);
int 	MHtmlGetPreviousLink(Widget wid, char **file, char **loc);
int 	MHtmlGetNextLink(Widget wid, char **file, char **loc);
int 	MHtmlGetFirstLink(Widget wid, char **file, char **loc);
void 	MHtmlClearHistoryCache(Widget wid);
char*   MHtmlLoadAndJump(Widget parent, String file, String loc);
int     MHtmlJumpToPreviousLink(Widget wid, char** link);
int     MHtmlJumpToNextLink(Widget wid, char** link);


#endif
