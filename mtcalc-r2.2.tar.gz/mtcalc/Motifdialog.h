#ifndef  _MotifDialog_
#define  _MotifDialog_
#define  PgmPath	"/server/softy/bin/"

typedef struct {
	Widget check_mylabel;
	char actualprogram[30];
	   } Transferlabel;

typedef struct  {
	XtInputId id;
	long int fan;
	FILE *pipe;
	char aircraft[5];
	char source[4];
	char mode[4];
	char datapath[50];
	char program[20];
	char filemask[30];
   	   } Aircraft;

int  GetMaskFiles  (char *fname , char * mask , int ndirects);
int  GetDataFiles  (char *fname , char * mask );
int  GetDataPath   (char *fname , char *extension);
int SetFiles(Widget wid , Aircraft *aircraft );
void ExtractInfo(char *fname,char *aircraft,long int *fan,char *mode,char *source);
void Push_files( Widget wid , char * pgmlabel , Aircraft *aircraft) ;
int SetFiles(Widget wid , Aircraft *aircraft );
void Push_dataareas( Widget wid ); 
void GrabDelete(Widget dialog , XtCallbackProc call ) ;
Widget create_wizant(Widget base , int xpos , int ypos );
void get16hex(char *string , long unsigned int *value) ;
void SetColorbyName(Widget target,char *ground ,char *col) ;
Bool MTextSetHex(Widget parent, int value);
unsigned int MTextGetHex(Widget parent);
Bool MTextSetHexlong(Widget parent, long long value);
long long MTextGetHexlong(Widget parent);
unsigned long GetColorbyName(Widget w , char *colorstr) ;
Widget CreatefilteredFBox (Widget parent, char *path ,void (*function)(char *)
		, char *title);

int  Get_FdF(char *fname , char * mask );
int SetFdFs(Widget wid , Aircraft *aircraft ) ;
int  GetFDFPath(char *fname , char *directory);
void nav_highlight(Widget w);
Widget HELP_Create(Widget parent,char *HelpFile);
#endif
