/* TYPEDEFS */

#ifndef _XMIND_INCLUDED
#define _XMIND_INCLUDED

typedef struct {                        /* Animation pixmap data        */
        Widget   w;
        Cardinal actualFrame;           /* Current frame to display     */
        Cardinal maxFrame;              /* Number of frames             */
        Cardinal counter;               /* How many times to play       */
        unsigned long time;             /* Intervall time in msec       */
        Pixmap  *pixmap;
	XtIntervalId id;		/* Intervall Id			*/
}AnimData;

typedef struct {
	char *	Qhelp_name;
	Widget	Qhelp_widget;
	char *	Hyper_object;
	char *	Hyper_file;
}USER_DATA;

#define XPM	1
#define XWD	2
#define XBM	3

#ifdef ANSI
#define P(x) x
#else
#define P(x) ()
#endif

/* Create Widgets Prototypes */
Pixel   MGetPixel(char *str, Widget w);
Bool    MListAddStrings(Widget parent, char **items, int number);
void MSetQuickhelp(Widget parent, USER_DATA *data, XEvent *event);
void MDestroyQuickhelp(Widget parent, USER_DATA *data, XmAnyCallbackStruct *cbs);
void 	MCloseDialog(Widget wid);
char   *MListGetString(Widget parent);
int 	MListGetPosition(Widget parent);
void 	MListDeleteAllItems(Widget parent);
Bool    MListAddString(Widget parent, char *item);



#endif
