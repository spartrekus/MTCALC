/*
        mindlib/misc.c

        This program is free software; you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation; either version 2, or (at your option)
        any later version.

        This program is distributed in the hope that it will be useful,
        but WITHOUT ANY WARRANTY; without even the implied warranty of
        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
        GNU General Public License for more details.

        You should have received a copy of the GNU General Public License
        along with this program; if not, write to the Free Software
        Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/cursorfont.h>
/*#include <X11/Xaw/Label.h>*/
#include <ctype.h>

#ifndef XtNcursor
#define XtNcursor	 "cursor"
#endif

#include "xpaint.h"

Widget GetShell(Widget w)
{
	while (!XtIsShell(w))
		w = XtParent(w);
	return w;
}

/*
**
*/
void GetPixmapWHD(Display *dpy, Drawable d, int *wth, int *hth, int *dth)
{
	Window		root;
	int		x, y;
	unsigned int	width, height, bw, depth;

	XGetGeometry(dpy, d, &root, &x, &y, &width, &height, &bw, &depth);

	if (wth != NULL) *wth = width;
	if (hth != NULL) *hth = height;
	if (dth != NULL) *dth = depth;
}

/*
**  Two useful functions to "cache" both a tiled background
**    and a Xor gc
*/
typedef struct bgList_s {
	int			depth;
	Pixmap			pixmap;
	struct	bgList_s	*next;
} BackgroundList;

typedef struct gcList_s {
	Widget			widget;
	int			depth;
	GC			gc;
	struct	gcList_s	*next;
} GCXList;

/*
**  Create a XImage
*/
XImage	*NewXImage(Display *dpy, Visual *visual, int depth, int width, int height)
{
	XImage	*xim;
	int	pad;

	if (depth > 16)
		pad = 32;
	else if (depth > 8)
		pad = 16;
	else
		pad = 8;

	xim = XCreateImage(dpy, visual, depth, ZPixmap, 0, NULL, width, height, pad, 0);	

	if (xim == NULL)
		return NULL;

	xim->data = (char*)XtMalloc(xim->bytes_per_line * height);

	if (xim->data == NULL) {
		XDestroyImage(xim);
		xim = NULL;
	}

	return xim;
}
